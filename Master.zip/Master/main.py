import os
import datetime
import threading
import time
import configparser
import tkinter as tk
from tkinter import scrolledtext, messagebox, simpledialog
import serial
import serial.tools.list_ports
import struct
import binascii
import queue


class Config:
    def __init__(self):
        self.serial_port = None
        self.baud_rate = 115200
        self.ratio = 1.0
        self.limit = 100.0
        self.is_scanning = False
        self.config_path = "config.ini"
        self.tf_root = "TF"  # TF卡根目录
        self.sample_folder = os.path.join(self.tf_root, "sample")  # 采样数据文件夹
        self.overlimit_folder = os.path.join(self.tf_root, "overLimit")  # 超阈值数据文件夹
        self.log_folder = os.path.join(self.tf_root, "log")  # 日志文件夹
        self.hidedata_folder = os.path.join(self.tf_root, "hideData")  # 加密数据文件夹
        self.log_id = 0  # 日志ID，从0开始
        self.enable_hide_storage = False  # 是否启用加密存储
        self.sample_count = 0  # 采样数据计数
        self.overlimit_count = 0  # 超阈值数据计数
        self.hidedata_count = 0  # 加密数据计数
        self.current_sample_file = None  # 当前采样数据文件
        self.current_overlimit_file = None  # 当前超阈值数据文件
        self.current_log_file = None  # 当前日志文件
        self.current_hidedata_file = None  # 当前加密数据文件
        self.led1_state = False  # LED1状态
        self.led2_state = False  # LED2状态
        self.rtc_time = datetime.datetime.now()  # RTC时间


config = Config()


class GD32F470Controller:
    # 命令定义保持不变，确保与设备端一致
    CMD_TEST = 0x01
    CMD_RTC_CONFIG = 0x02
    CMD_RTC_NOW = 0x03
    CMD_READ_CONFIG = 0x04
    CMD_SET_RATIO = 0x05
    CMD_GET_RATIO = 0x06
    CMD_SET_LIMIT = 0x07
    CMD_GET_LIMIT = 0x08
    CMD_SAVE_CONFIG = 0x09
    CMD_READ_CONFIG_FLASH = 0x0A
    CMD_START_SCAN = 0x0B
    CMD_STOP_SCAN = 0x0C
    CMD_ENABLE_HIDE = 0x0D
    CMD_DISABLE_HIDE = 0x0E
    CMD_SET_LED1 = 0x0F
    CMD_SET_LED2 = 0x10
    CMD_GET_SAMPLE = 0x11
    CMD_UPDATE_OLED = 0x20  # 保持与设备端一致

    # 响应状态
    RESP_SUCCESS = 0x00
    RESP_ERROR = 0x01
    RESP_INVALID_CMD = 0x02
    RESP_INVALID_PARAM = 0x03
    RESP_DATA = 0x04

    def __init__(self, master):
        self.master = master
        self.serial_conn = None
        self.data_queue = queue.Queue()
        self.receive_thread = None
        self.running = False

    def connect(self, port=None):
        """连接到GD32F470板"""
        if self.serial_conn and self.serial_conn.is_open:
            self.serial_conn.close()

        try:
            # 自动查找可用串口
            if port is None:
                ports = list(serial.tools.list_ports.comports())
                if not ports:
                    return False, "未找到可用串口"
                port = ports[0].device

            self.serial_conn = serial.Serial(port, config.baud_rate, timeout=1)
            config.serial_port = port

            # 启动数据接收线程
            self.running = True
            self.receive_thread = threading.Thread(target=self.receive_data_loop)
            self.receive_thread.daemon = True
            self.receive_thread.start()

            return True, f"已连接到 {port}"
        except Exception as e:
            return False, f"连接失败: {str(e)}"

    def disconnect(self):
        """断开与GD32F470板的连接"""
        self.running = False
        if self.receive_thread and self.receive_thread.is_alive():
            self.receive_thread.join(1.0)

        if self.serial_conn and self.serial_conn.is_open:
            # 在关闭连接前发送一个特殊命令，让设备显示disconnected
            try:
                # 使用OLED状态更新命令
                self.send_command(self.CMD_UPDATE_OLED, [0])  # 0表示disconnected
                # 给设备一点时间处理
                time.sleep(0.1)
            except Exception:
                # 忽略发送错误
                pass

            self.serial_conn.close()
            return True, "已断开连接"
        return False, "未连接"

    def send_command(self, cmd, data=None, retry=3):
        """向GD32F470板发送命令，带重试机制"""
        if not self.serial_conn or not self.serial_conn.is_open:
            return False, "未连接到设备"

        for attempt in range(retry):
            try:
                # 构建命令帧
                frame = bytearray()
                frame.append(0xAA)  # 帧头
                frame.append(cmd)  # 命令

                # 添加数据长度和数据
                if data:
                    frame.append(len(data))  # 数据长度
                    frame.extend(data)
                else:
                    frame.append(0)  # 数据长度=0

                # 计算校验和
                checksum = sum(frame) & 0xFF
                frame.append(checksum)
                frame.append(0x55)  # 帧尾

                # 发送命令前清空接收缓冲区
                self.serial_conn.reset_input_buffer()

                # 发送命令
                self.serial_conn.write(frame)

                # 打印调试信息
                debug_str = "发送: " + " ".join([f"{b:02X}" for b in frame])
                print(debug_str)

                # 等待一小段时间，确保命令被发送
                time.sleep(0.1)

                return True, "命令已发送"
            except serial.SerialException as e:
                if attempt == retry - 1:
                    return False, f"发送失败(重试{retry}次): {str(e)}"
                time.sleep(0.1)
            except Exception as e:
                return False, f"发送命令失败: {str(e)}"

    def receive_data_loop(self):
        """数据接收循环，持续监听串口数据"""
        buffer = bytearray()
        while self.running and self.serial_conn and self.serial_conn.is_open:
            try:
                # 读取可用数据
                if self.serial_conn.in_waiting > 0:
                    data = self.serial_conn.read(self.serial_conn.in_waiting)
                    if data:
                        # 打印接收到的原始数据（调试用）
                        debug_str = "接收: " + " ".join([f"{b:02X}" for b in data])
                        print(debug_str)

                        buffer.extend(data)

                        # 处理接收缓冲区
                        while len(buffer) >= 5:  # 最小帧长度: 帧头+cmd+len+checksum+帧尾
                            # 查找帧头
                            if buffer[0] != 0xAA:
                                buffer.pop(0)
                                continue

                            # 获取数据长度
                            if len(buffer) < 3:
                                break

                            cmd = buffer[1]
                            data_len = buffer[2]
                            total_len = 4 + data_len + 1  # 帧头+cmd+len+data+checksum+帧尾

                            if len(buffer) < total_len:
                                break

                            # 提取完整帧
                            frame = buffer[:total_len]

                            # 校验帧尾和校验和
                            if frame[-1] == 0x55 and self.validate_frame(frame):  # 验证整个帧
                                print(f"有效帧: {' '.join([f'{b:02X}' for b in frame])}")
                                self.process_frame(frame)
                            else:
                                print(f"无效帧: {' '.join([f'{b:02X}' for b in frame])}")

                            # 移除已处理的帧
                            buffer = buffer[total_len:]
                else:
                    # 如果没有数据，短暂休眠以减少CPU使用
                    time.sleep(0.01)

            except Exception as e:
                print(f"接收数据错误: {str(e)}")
                time.sleep(0.1)

    def validate_frame(self, frame):
        """验证帧的校验和"""
        if len(frame) < 5:
            return False

        # 计算校验和 (不包括帧尾)
        checksum = sum(frame[:-2]) & 0xFF  # 帧头+cmd+len+data部分
        return checksum == frame[-2]  # 倒数第二个字节是校验和

    def process_frame(self, frame):
        """处理接收到的帧"""
        if len(frame) < 5:
            return

        cmd = frame[1]
        data_len = frame[2]
        data_start = 3
        data_end = data_start + data_len
        data = frame[data_start:data_end] if data_len > 0 else None

        # 根据命令类型处理
        if cmd == self.CMD_RTC_NOW and data_len >= 6:
            # 解析RTC时间 (年2字节 + 月1 + 日1 + 时1 + 分1 + 秒1)
            year = (data[0] << 8) | data[1]
            month = data[2]
            day = data[3]
            hour = data[4]
            minute = data[5]
            second = data[6] if data_len >= 7 else 0
            try:
                rtc_time = datetime.datetime(year, month, day, hour, minute, second)
                self.data_queue.put(("rtc", rtc_time))
            except ValueError:
                print(f"无效的RTC时间: {year}-{month}-{day} {hour}:{minute}:{second}")

        elif cmd == self.CMD_READ_CONFIG_FLASH and data_len >= 8:
            # 解析配置数据 (变比4字节 + 阈值4字节)
            ratio = struct.unpack('>f', data[0:4])[0]
            limit = struct.unpack('>f', data[4:8])[0]
            self.data_queue.put(("config", ratio, limit))

        elif cmd == self.CMD_GET_SAMPLE and data_len >= 8:
            # 解析采样数据 (时间戳4字节 + 电压4字节)
            timestamp = struct.unpack('>I', data[0:4])[0]
            voltage = struct.unpack('>f', data[4:8])[0]
            self.data_queue.put(("data", timestamp, voltage))

        # OLED状态响应
        elif cmd == self.CMD_UPDATE_OLED and data_len >= 1:
            status = data[0]
            status_map = {
                0: "disconnected",
                1: "system idle",
                2: "system sampling"
            }
            oled_status = status_map.get(status, "unknown")
            self.data_queue.put(("oled_status", oled_status))

        # 测试命令响应
        elif cmd == self.CMD_TEST:
            if data and data_len > 0:
                status = data[0]
                self.data_queue.put(("status", cmd, status))

        # RTC配置响应
        elif cmd == self.CMD_RTC_CONFIG:
            if data and data_len > 0:
                status = data[0]
                self.data_queue.put(("status", cmd, status))

        else:
            # 处理状态响应
            status = data[0] if data_len > 0 else self.RESP_ERROR
            self.data_queue.put(("status", cmd, status))


class PowerShellGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("GD32F470 控制台")
        self.root.geometry("800x600")

        self.controller = GD32F470Controller(self.root)
        self.setup_ui()

        # 初始化OLED状态为disconnected
        self.oled_status = "disconnected"

        # 初始化隐藏格式状态
        self.is_hidden_format = False

        # 初始化存储系统
        self.init_storage_system()

        # 启动数据处理器
        self.process_data()

        # 记录初始状态
        self.print_output("GD32F470 PowerShell控制台已启动")
        self.print_output("使用'help'命令获取帮助")
        self.print_output("OLED显示'disconnected'")

    def setup_ui(self):
        """设置用户界面"""
        # 创建主框架
        main_frame = tk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # 创建输出区域
        output_frame = tk.Frame(main_frame)
        output_frame.pack(fill=tk.BOTH, expand=True)

        # 输出文本区域
        self.output_text = scrolledtext.ScrolledText(output_frame, wrap=tk.WORD, bg="black", fg="white")
        self.output_text.pack(fill=tk.BOTH, expand=True)
        self.output_text.configure(state=tk.DISABLED)

        # 创建命令输入区域
        input_frame = tk.Frame(main_frame)
        input_frame.pack(fill=tk.X, pady=5)

        # 命令提示符
        prompt_label = tk.Label(input_frame, text="PS>")
        prompt_label.pack(side=tk.LEFT, padx=5)

        # 命令输入框
        self.command_entry = tk.Entry(input_frame)
        self.command_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.command_entry.bind("<Return>", self.execute_command)
        self.command_entry.focus_set()

        # 创建按钮区域
        button_frame = tk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=5)

        # 连接按钮
        connect_button = tk.Button(button_frame, text="连接", command=self.connect_device)
        connect_button.pack(side=tk.LEFT, padx=5)

        # 断开按钮
        disconnect_button = tk.Button(button_frame, text="断开", command=self.disconnect_device)
        disconnect_button.pack(side=tk.LEFT, padx=5)

        # 测试按钮
        test_button = tk.Button(button_frame, text="Test", command=self.test_command)
        test_button.pack(side=tk.LEFT, padx=5)

        # RTC配置按钮
        rtc_config_button = tk.Button(button_frame, text="RTCConfig", command=self.rtc_config)
        rtc_config_button.pack(side=tk.LEFT, padx=5)

        # 获取当前时间按钮
        now_button = tk.Button(button_frame, text="Now", command=self.rtc_now)
        now_button.pack(side=tk.LEFT, padx=5)

        # 读取配置按钮
        conf_button = tk.Button(button_frame, text="Conf", command=self.read_config)
        conf_button.pack(side=tk.LEFT, padx=5)

        # 加密存储按钮
        self.hide_button = tk.Button(
            button_frame,
            text=f"加密存储: {'开' if config.enable_hide_storage else '关'}",
            command=self.toggle_hide_storage
        )
        self.hide_button.pack(side=tk.LEFT, padx=5)

        # 创建状态栏
        self.status_bar = tk.Label(self.root, text="未连接", bd=1, relief=tk.SUNKEN, anchor=tk.W)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        # 创建配置显示区域
        config_frame = tk.Frame(main_frame)
        config_frame.pack(fill=tk.X, pady=5)

        # 变比和阈值显示
        self.ratio_label = tk.Label(config_frame, text=f"变比: {config.ratio:.3f}")
        self.ratio_label.pack(side=tk.LEFT, padx=10)

        self.limit_label = tk.Label(config_frame, text=f"阈值: {config.limit:.1f}V")
        self.limit_label.pack(side=tk.LEFT, padx=10)

    def init_storage_system(self):
        """初始化存储系统"""
        # 确保目录存在
        os.makedirs(config.sample_folder, exist_ok=True)
        os.makedirs(config.overlimit_folder, exist_ok=True)
        os.makedirs(config.log_folder, exist_ok=True)
        os.makedirs(config.hidedata_folder, exist_ok=True)

        # 创建日志文件
        self.create_log_file()

    def create_log_file(self):
        """创建新的日志文件"""
        try:
            # 生成日志文件名
            datetime_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            log_filename = f"log_{config.log_id:03d}_{datetime_str}.txt"
            config.current_log_file = os.path.join(config.log_folder, log_filename)

            # 创建日志文件并写入头部信息
            with open(config.current_log_file, 'w') as f:
                f.write(f"GD32F470 控制台日志 - ID: {config.log_id}\n")
                f.write(f"开始时间: {datetime_str}\n")
                f.write("-" * 50 + "\n\n")

            # 增加日志ID
            config.log_id += 1

            self.print_output(f"创建日志文件: {log_filename}")
            return True

        except Exception as e:
            print(f"创建日志文件失败: {str(e)}")
            return False

    def validate_frame(self, frame):
        """验证帧的校验和"""
        # 计算除了校验和本身外的所有字节的和
        checksum = sum(frame[:-1]) & 0xFF
        # 比较计算的校验和与帧中的校验和
        return checksum == frame[-1]

    def process_frame(self, frame):
        """处理接收到的完整帧"""
        # 提取命令和数据
        cmd = frame[1]
        data_len = frame[2]
        data = frame[3:3 + data_len] if data_len > 0 else None

        # 根据命令类型处理
        if cmd == self.controller.RESP_SUCCESS:
            self.data_queue.put(("status", cmd, self.controller.RESP_SUCCESS))
        elif cmd == self.controller.RESP_ERROR:
            self.data_queue.put(("status", cmd, self.controller.RESP_ERROR))
        elif cmd == self.controller.RESP_INVALID_CMD:
            self.data_queue.put(("status", cmd, self.controller.RESP_INVALID_CMD))
        elif cmd == self.controller.RESP_INVALID_PARAM:
            self.data_queue.put(("status", cmd, self.controller.RESP_INVALID_PARAM))
        elif cmd == self.controller.RESP_DATA and data_len >= 8:
            # 解析时间戳 (4字节)
            timestamp = struct.unpack('>I', data[0:4])[0]
            # 解析电压值 (4字节 IEEE 754浮点数)
            voltage = struct.unpack('>f', data[4:8])[0]
            self.data_queue.put(("data", timestamp, voltage))
        elif cmd == self.controller.CMD_RTC_NOW and data_len >= 7:
            # 解析RTC时间
            year = 2000 + data[0]
            month = data[1]
            day = data[2]
            hour = data[3]
            minute = data[4]
            second = data[5]
            # 创建datetime对象
            rtc_time = datetime.datetime(year, month, day, hour, minute, second)
            self.data_queue.put(("rtc", rtc_time))
        elif cmd == self.controller.CMD_READ_CONFIG_FLASH and data_len >= 8:
            # 解析变比和阈值
            ratio = struct.unpack('>f', data[0:4])[0]
            limit = struct.unpack('>f', data[4:8])[0]
            self.data_queue.put(("config", ratio, limit))

    def process_data(self):
        """处理来自控制器的数据"""
        try:
            # 限制每次处理的最大消息数
            for _ in range(10):
                if self.controller.data_queue.empty():
                    break

                data_type, *data = self.controller.data_queue.get_nowait()

                if data_type == "status":
                    cmd, status = data
                    status_text = self.get_status_text(status)
                    self.print_output(f"命令响应: {self.get_cmd_text(cmd)} -> {status_text}")

                elif data_type == "data":
                    timestamp, voltage = data
                    # 转换时间戳为可读格式
                    time_str = datetime.datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")

                    # 使用新的处理函数
                    display_text = self.process_voltage_data(timestamp, voltage, time_str)
                    self.print_output(display_text)

                # 其他数据类型处理...
                elif data_type == "rtc":
                    rtc_time = data[0]
                    config.rtc_time = rtc_time
                    self.print_output(f"当前RTC时间: {rtc_time.strftime('%Y-%m-%d %H:%M:%S')}")

                elif data_type == "config":
                    ratio, limit = data
                    config.ratio = ratio
                    config.limit = limit
                    self.print_output(f"从Flash读取配置: 变比={ratio:.3f}, 阈值={limit:.1f}V")
                    self.update_config_display()  # 更新配置显示

                elif data_type == "oled_status":
                    self.oled_status = data[0]
                    self.print_output(f"OLED显示: '{self.oled_status}'")

        except queue.Empty:
            pass
        except Exception as e:
            self.print_output(f"处理数据错误: {str(e)}")

        # 调整轮询间隔
        self.root.after(50, self.process_data)

    def process_voltage_data(self, timestamp, voltage, time_str):
        """处理电压数据，包括存储和显示"""
        # 检查是否超过阈值
        is_over_limit = voltage > config.limit

        # 格式化显示文本
        if self.is_hidden_format:
            display_text = f"数据: {timestamp}, {binascii.hexlify(struct.pack('>f', voltage)).decode()}"
        else:
            display_text = f"采样: {time_str}, 电压: {voltage:.2f}V"
            if is_over_limit:
                display_text += " [超过阈值]"

        # 存储数据
        self.store_voltage_data(timestamp, voltage, time_str, is_over_limit)

        return display_text

    def store_voltage_data(self, timestamp, voltage, time_str, is_over_limit):
        """存储电压数据到文件"""
        try:
            # 确保目录存在
            os.makedirs(config.sample_folder, exist_ok=True)
            os.makedirs(config.overlimit_folder, exist_ok=True)
            if config.enable_hide_storage:
                os.makedirs(config.hidedata_folder, exist_ok=True)

            # 使用日期作为文件名
            date_str = datetime.datetime.now().strftime("%Y%m%d")

            # 采样数据文件
            if not config.current_sample_file or date_str not in os.path.basename(config.current_sample_file):
                config.current_sample_file = os.path.join(
                    config.sample_folder, f"sample_{date_str}.csv")
                file_exists = os.path.exists(config.current_sample_file)

                with open(config.current_sample_file, 'a' if file_exists else 'w') as f:
                    if not file_exists:
                        f.write("时间戳,时间,电压(V)\n")

            # 写入数据
            with open(config.current_sample_file, 'a') as f:
                f.write(f"{timestamp},{time_str},{voltage:.6f}\n")
            config.sample_count += 1

            # 超阈值数据存储
            if is_over_limit:
                if not config.current_overlimit_file or date_str not in os.path.basename(config.current_overlimit_file):
                    config.current_overlimit_file = os.path.join(
                        config.overlimit_folder, f"overlimit_{date_str}.csv")
                    file_exists = os.path.exists(config.current_overlimit_file)

                    with open(config.current_overlimit_file, 'a' if file_exists else 'w') as f:
                        if not file_exists:
                            f.write("时间戳,时间,电压(V)\n")

                with open(config.current_overlimit_file, 'a') as f:
                    f.write(f"{timestamp},{time_str},{voltage:.6f}\n")
                config.overlimit_count += 1

            # 加密数据存储
            if config.enable_hide_storage:
                if not config.current_hidedata_file or date_str not in os.path.basename(config.current_hidedata_file):
                    config.current_hidedata_file = os.path.join(
                        config.hidedata_folder, f"hide_{date_str}.bin")

                with open(config.current_hidedata_file, 'ab') as f:
                    # 写入时间戳和电压值的二进制表示
                    f.write(struct.pack('>If', timestamp, voltage))
                config.hidedata_count += 1

        except Exception as e:
            self.print_output(f"存储数据错误: {str(e)}")

    def get_status_text(self, status):
        """获取状态文本"""
        status_map = {
            self.controller.RESP_SUCCESS: "成功",
            self.controller.RESP_ERROR: "错误",
            self.controller.RESP_INVALID_CMD: "无效命令",
            self.controller.RESP_INVALID_PARAM: "无效参数"
        }
        return status_map.get(status, f"未知状态({status})")

    def get_cmd_text(self, cmd):
        """获取命令文本"""
        cmd_map = {
            self.controller.CMD_TEST: "测试",
            self.controller.CMD_RTC_CONFIG: "RTC配置",
            self.controller.CMD_RTC_NOW: "RTC时间",
            self.controller.CMD_READ_CONFIG: "读取配置",
            self.controller.CMD_SET_RATIO: "设置变比",
            self.controller.CMD_GET_RATIO: "获取变比",
            self.controller.CMD_SET_LIMIT: "设置阈值",
            self.controller.CMD_GET_LIMIT: "获取阈值",
            self.controller.CMD_SAVE_CONFIG: "保存配置",
            self.controller.CMD_READ_CONFIG_FLASH: "从Flash读取配置",
            self.controller.CMD_START_SCAN: "开始扫描",
            self.controller.CMD_STOP_SCAN: "停止扫描",
            self.controller.CMD_ENABLE_HIDE: "启用隐藏格式",
            self.controller.CMD_DISABLE_HIDE: "禁用隐藏格式",
            self.controller.CMD_SET_LED1: "设置LED1",
            self.controller.CMD_SET_LED2: "设置LED2",
            self.controller.CMD_GET_SAMPLE: "获取采样",
            self.controller.CMD_UPDATE_OLED: "更新OLED"
        }
        return cmd_map.get(cmd, f"未知命令({cmd})")

    def update_config_display(self):
        """更新配置显示"""
        self.ratio_label.config(text=f"变比: {config.ratio:.3f}")
        self.limit_label.config(text=f"阈值: {config.limit:.1f}V")

    def connect_device(self):
        """连接设备"""
        # 如果已经连接，先断开
        if self.controller.serial_conn and self.controller.serial_conn.is_open:
            self.disconnect_device()
            # 等待端口释放
            time.sleep(1)

        # 获取可用串口列表
        ports = list(serial.tools.list_ports.comports())
        port_list = [p.device for p in ports]

        if not port_list:
            messagebox.showwarning("警告", "未找到可用串口")
            return

        # 如果只有一个串口，直接连接
        if len(port_list) == 1:
            port = port_list[0]
        else:
            # 让用户选择串口
            port = simpledialog.askstring(
                "选择串口",
                f"请选择串口 (可用: {', '.join(port_list)})",
                initialvalue=port_list[0] if port_list else ""
            )
            if not port:
                return

        # 尝试连接设备，添加重试机制
        max_retries = 3
        for attempt in range(max_retries):
            try:
                # 连接设备
                success, message = self.controller.connect(port)
                self.print_output(message)

                if success:
                    self.status_bar.config(text=f"已连接到 {port}")
                    self.oled_status = "system idle"
                    self.print_output(f"OLED显示'{self.oled_status}'")

                    # 发送OLED状态更新命令
                    self.controller.send_command(
                        self.controller.CMD_UPDATE_OLED,
                        [1]  # 1表示idle状态
                    )
                    return

            except Exception as e:
                self.print_output(f"连接尝试 {attempt + 1}/{max_retries} 失败: {str(e)}")

            # 如果连接失败，等待一段时间后重试
            if attempt < max_retries - 1:
                self.print_output(f"等待 1 秒后重试...")
                time.sleep(1)

        self.print_output(f"连接到 {port} 失败，请确保端口未被其他程序占用")
        messagebox.showerror("连接错误", f"无法连接到 {port}，请确保端口未被其他程序占用")

    def disconnect_device(self):
        """断开设备连接"""
        # 在关闭连接前发送OLED更新命令
        if self.controller.serial_conn and self.controller.serial_conn.is_open:
            self.controller.send_command(
                self.controller.CMD_UPDATE_OLED,
                [0]  # 0表示disconnected
            )
            time.sleep(0.1)  # 给设备一点时间处理

        success, message = self.controller.disconnect()
        self.print_output(message)

        if success:
            self.status_bar.config(text="未连接")
            self.oled_status = "disconnected"
            self.print_output(f"OLED显示'{self.oled_status}'")

            # 关闭当前文件
            self.close_current_files()

    def close_current_files(self):
        """关闭当前打开的所有文件"""
        config.current_sample_file = None
        config.current_overlimit_file = None
        config.current_hidedata_file = None

        # 创建新的日志文件
        self.create_log_file()

    def test_command(self):
        """执行测试命令"""
        # 发送带测试数据的测试命令
        success, message = self.controller.send_command(
            self.controller.CMD_TEST,
            [0xAA, 0x55]  # 测试数据
        )
        if not success:
            self.print_output(message)
            return

        self.print_output("发送测试命令...")

    def rtc_config(self):
        """配置RTC时间"""
        # 获取当前时间作为默认值
        now = datetime.datetime.now()
        default_time = now.strftime("%Y-%m-%d %H:%M:%S")

        # 弹出对话框让用户输入时间
        time_str = simpledialog.askstring(
            "设置RTC时间",
            "请输入时间 (格式: YYYY-MM-DD HH:MM:SS):",
            initialvalue=default_time
        )

        if not time_str:
            return

        try:
            # 解析时间字符串
            dt = datetime.datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S")

            # 构建符合设备要求的7字节时间数据
            data = [
                (dt.year - 2000) & 0xFF,  # 年份偏移
                dt.month,
                dt.day,
                dt.hour,
                dt.minute,
                dt.second,
                0  # 星期几占位符
            ]

            # 发送命令
            success, message = self.controller.send_command(
                self.controller.CMD_RTC_CONFIG,
                data
            )

            if not success:
                self.print_output(message)
                return

            self.print_output(f"设置RTC时间为: {time_str}")

        except ValueError:
            self.print_output("错误: 时间格式无效")

    def rtc_now(self):
        """获取当前RTC时间"""
        success, message = self.controller.send_command(self.controller.CMD_RTC_NOW)
        if not success:
            self.print_output(message)
            return

        self.print_output("获取RTC时间...")

    def read_config(self):
        """读取配置"""
        # 先发送保存配置命令确保配置有效
        self.controller.send_command(self.controller.CMD_SAVE_CONFIG)
        time.sleep(0.2)

        # 再读取配置
        success, message = self.controller.send_command(
            self.controller.CMD_READ_CONFIG_FLASH
        )
        if not success:
            self.print_output(message)
            return
        self.print_output("读取配置...")

    def set_led(self, led_num, state):
        """设置LED状态"""
        cmd = self.controller.CMD_SET_LED1 if led_num == 1 else self.controller.CMD_SET_LED2
        data = [1 if state else 0]

        success, message = self.controller.send_command(cmd, data)
        if not success:
            self.print_output(message)
            return

        # 更新LED状态
        if led_num == 1:
            config.led1_state = state
        else:
            config.led2_state = state

        self.print_output(f"设置LED{led_num}为{'开' if state else '关'}")

    def toggle_hide_storage(self):
        """切换加密存储模式"""
        config.enable_hide_storage = not config.enable_hide_storage

        # 更新按钮文本
        self.hide_button.config(
            text=f"加密存储: {'开' if config.enable_hide_storage else '关'}")

        self.print_output(f"{'启用' if config.enable_hide_storage else '禁用'}加密存储")

        # 关闭当前文件并创建新文件
        config.current_hidedata_file = None

    def execute_command(self, event=None):
        """执行命令行输入的命令"""
        command = self.command_entry.get().strip()
        self.command_entry.delete(0, tk.END)

        if not command:
            return

        self.print_output(f"PS> {command}")

        # 解析命令
        parts = command.split()
        cmd = parts[0].lower()
        args = parts[1:] if len(parts) > 1 else []

        # 处理命令
        if cmd == "help":
            self.show_help()
        elif cmd == "connect":
            self.connect_device()
        elif cmd == "disconnect":
            self.disconnect_device()
        elif cmd == "test":
            self.test_command()
        elif cmd == "rtcconfig":
            self.rtc_config()
        elif cmd == "now":
            self.rtc_now()
        elif cmd == "conf":
            self.read_config()
        elif cmd == "ratio":
            self.handle_ratio_command(args)
        elif cmd == "limit":
            self.handle_limit_command(args)
        elif cmd == "config":
            self.handle_config_command(args)
        elif cmd == "start":
            self.start_scan()
        elif cmd == "stop":
            self.stop_scan()
        elif cmd == "hide":
            self.enable_hide_format()
        elif cmd == "unhide":
            self.disable_hide_format()
        elif cmd == "led":
            self.handle_led_command(args)
        elif cmd == "status":
            self.show_status()
        elif cmd == "testcomm":
            self.test_communication()
        else:
            self.print_output(f"错误: 未知命令 '{cmd}'")

    def show_help(self):
        """显示帮助信息"""
        help_text = """
可用命令:
  help                - 显示此帮助信息
  connect             - 连接到设备
  disconnect          - 断开设备连接
  test                - 执行自测试
  rtcconfig           - 设置RTC时间
  now                 - 获取当前RTC时间
  conf                - 读取配置
  ratio [value]       - 获取/设置变比
  limit [value]       - 获取/设置阈值
  config save         - 保存配置到Flash
  config read         - 从Flash读取配置
  start               - 开始扫描
  stop                - 停止扫描
  hide                - 启用隐藏格式
  unhide              - 禁用隐藏格式
  led <1|2> <on|off>  - 控制LED
  status              - 显示系统状态
  testcomm            - 测试与设备的通信
"""
        self.print_output(help_text)

    def handle_ratio_command(self, args):
        """处理变比命令"""
        if not args:
            # 获取当前变比
            success, message = self.controller.send_command(self.controller.CMD_GET_RATIO)
            if not success:
                self.print_output(message)
                return

            self.print_output(f"当前变比: {config.ratio:.3f}")
            return

        try:
            # 设置新变比
            new_ratio = float(args[0])
            if new_ratio <= 0:
                self.print_output("错误: 变比必须大于0")
                return

            # 发送命令
            data = struct.pack('>f', new_ratio)
            success, message = self.controller.send_command(
                self.controller.CMD_SET_RATIO, list(data))

            if not success:
                self.print_output(message)
                return

            config.ratio = new_ratio
            self.update_config_display()
            self.print_output(f"设置变比为: {new_ratio:.3f}")

        except ValueError:
            self.print_output("错误: 无效的变比值")

    def handle_limit_command(self, args):
        """处理阈值命令"""
        if not args:
            # 获取当前阈值
            success, message = self.controller.send_command(self.controller.CMD_GET_LIMIT)
            if not success:
                self.print_output(message)
                return

            self.print_output(f"当前阈值: {config.limit:.1f}V")
            return

        try:
            # 设置新阈值
            new_limit = float(args[0])
            if new_limit < 0:
                self.print_output("错误: 阈值不能为负")
                return

            # 发送命令
            data = struct.pack('>f', new_limit)
            success, message = self.controller.send_command(
                self.controller.CMD_SET_LIMIT, list(data))

            if not success:
                self.print_output(message)
                return

            config.limit = new_limit
            self.update_config_display()
            self.print_output(f"设置阈值为: {new_limit:.1f}V")

        except ValueError:
            self.print_output("错误: 无效的阈值值")

    def handle_config_command(self, args):
        """处理配置命令"""
        if not args:
            self.print_output("错误: 缺少子命令 (save/read)")
            return

        subcmd = args[0].lower()

        if subcmd == "save":
            # 保存配置到Flash
            success, message = self.controller.send_command(self.controller.CMD_SAVE_CONFIG)
            if not success:
                self.print_output(message)
                return

            self.print_output("保存配置到Flash...")

        elif subcmd == "read":
            # 从Flash读取配置
            success, message = self.controller.send_command(self.controller.CMD_READ_CONFIG_FLASH)
            if not success:
                self.print_output(message)
                return

            self.print_output("从Flash读取配置...")

        else:
            self.print_output(f"错误: 未知子命令 '{subcmd}'")

    def start_scan(self):
        """开始扫描"""
        success, message = self.controller.send_command(self.controller.CMD_START_SCAN)
        if not success:
            self.print_output(message)
            return

        config.is_scanning = True
        self.oled_status = "system sampling"
        self.print_output("开始扫描...")

        # 发送OLED更新命令
        self.controller.send_command(
            self.controller.CMD_UPDATE_OLED,
            [2]  # 2表示sampling状态
        )

        # 创建新的数据文件
        self.close_current_files()

    def stop_scan(self):
        """停止扫描"""
        success, message = self.controller.send_command(self.controller.CMD_STOP_SCAN)
        if not success:
            self.print_output(message)
            return

        config.is_scanning = False
        self.oled_status = "system idle"
        self.print_output("停止扫描...")

        # 发送OLED更新命令
        self.controller.send_command(
            self.controller.CMD_UPDATE_OLED,
            [1]  # 1表示idle状态
        )

    def enable_hide_format(self):
        """启用隐藏格式"""
        success, message = self.controller.send_command(self.controller.CMD_ENABLE_HIDE)
        if not success:
            self.print_output(message)
            return

        self.is_hidden_format = True
        self.print_output("启用隐藏格式")

    def disable_hide_format(self):
        """禁用隐藏格式"""
        success, message = self.controller.send_command(self.controller.CMD_DISABLE_HIDE)
        if not success:
            self.print_output(message)
            return

        self.is_hidden_format = False
        self.print_output("禁用隐藏格式")

    def handle_led_command(self, args):
        """处理LED命令"""
        if len(args) < 2:
            self.print_output("错误: 缺少参数 (格式: led <1|2> <on|off>)")
            return

        try:
            led_num = int(args[0])
            if led_num not in [1, 2]:
                self.print_output("错误: LED编号必须是1或2")
                return

            state_str = args[1].lower()
            if state_str == "on":
                state = True
            elif state_str == "off":
                state = False
            else:
                self.print_output("错误: 状态必须是on或off")
                return

            self.set_led(led_num, state)

        except ValueError:
            self.print_output("错误: 无效的LED编号")

    def show_status(self):
        """显示系统状态"""
        status_text = f"""
系统状态:
  连接状态: {'已连接' if self.controller.serial_conn and self.controller.serial_conn.is_open else '未连接'}
  串口: {config.serial_port if config.serial_port else 'N/A'}
  波特率: {config.baud_rate}

配置:
  变比: {config.ratio:.3f}
  阈值: {config.limit:.1f}V

扫描状态: {'正在扫描' if config.is_scanning else '已停止'}
隐藏格式: {'启用' if self.is_hidden_format else '禁用'}
加密存储: {'启用' if config.enable_hide_storage else '禁用'}

LED状态:
  LED1: {'开' if config.led1_state else '关'}
  LED2: {'开' if config.led2_state else '关'}

数据统计:
  采样数据: {config.sample_count}条
  超阈值数据: {config.overlimit_count}条
  加密数据: {config.hidedata_count}条

OLED显示: '{self.oled_status}'
"""
        self.print_output(status_text)

    def load_config_from_file(self):
        """从配置文件加载配置"""
        try:
            if not os.path.exists(config.config_path):
                self.print_output(f"配置文件 {config.config_path} 不存在，使用默认配置")
                return False

            parser = configparser.ConfigParser()
            parser.read(config.config_path)

            # 读取串口配置
            if 'Serial' in parser:
                if 'port' in parser['Serial']:
                    config.serial_port = parser['Serial']['port']
                if 'baud_rate' in parser['Serial']:
                    config.baud_rate = int(parser['Serial']['baud_rate'])

            # 读取参数配置
            if 'Parameters' in parser:
                if 'ratio' in parser['Parameters']:
                    config.ratio = float(parser['Parameters']['ratio'])
                if 'limit' in parser['Parameters']:
                    config.limit = float(parser['Parameters']['limit'])

            # 读取日志配置
            if 'Log' in parser:
                if 'log_id' in parser['Log']:
                    config.log_id = int(parser['Log']['log_id'])

            self.update_config_display()
            self.print_output(f"从 {config.config_path} 加载配置成功")
            return True

        except Exception as e:
            self.print_output(f"加载配置文件错误: {str(e)}")
            return False

    def save_config_to_file(self):
        """保存配置到文件"""
        try:
            parser = configparser.ConfigParser()

            # 串口配置
            parser['Serial'] = {
                'port': config.serial_port if config.serial_port else '',
                'baud_rate': str(config.baud_rate)
            }

            # 参数配置
            parser['Parameters'] = {
                'ratio': str(config.ratio),
                'limit': str(config.limit)
            }

            # 日志配置
            parser['Log'] = {
                'log_id': str(config.log_id)
            }

            # 写入文件
            with open(config.config_path, 'w') as f:
                parser.write(f)

            self.print_output(f"配置已保存到 {config.config_path}")
            return True

        except Exception as e:
            self.print_output(f"保存配置文件错误: {str(e)}")
            return False

    def print_output(self, text):
        """向输出区域添加文本"""
        self.output_text.configure(state=tk.NORMAL)
        self.output_text.insert(tk.END, text + "\n")
        self.output_text.see(tk.END)  # 自动滚动到底部
        self.output_text.configure(state=tk.DISABLED)

        # 同时写入日志文件
        if config.current_log_file:
            try:
                with open(config.current_log_file, 'a') as f:
                    # 添加时间戳
                    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    f.write(f"[{timestamp}] {text}\n")
            except Exception as e:
                print(f"写入日志文件失败: {str(e)}")

    def test_communication(self):
        """测试与设备的通信"""
        self.print_output("开始通信测试...")

        # 1. 发送测试命令
        success, message = self.controller.send_command(self.controller.CMD_TEST)
        if not success:
            self.print_output(f"测试命令发送失败: {message}")
            return False

        self.print_output("已发送测试命令，等待响应...")

        # 2. 等待响应
        response_received = False
        start_time = time.time()
        timeout = 3.0  # 3秒超时

        while time.time() - start_time < timeout:
            try:
                if not self.controller.data_queue.empty():
                    data_type, *data = self.controller.data_queue.get_nowait()
                    if data_type == "status":
                        response_received = True
                        self.print_output(f"收到响应: {data}")
                        break
            except:
                pass

            # 短暂休眠
            time.sleep(0.1)

        if not response_received:
            self.print_output("通信测试失败: 未收到响应")
            return False

        self.print_output("通信测试成功!")
        return True


def main():
    """主函数"""
    # 创建TF卡目录结构
    os.makedirs("TF", exist_ok=True)
    os.makedirs("TF/sample", exist_ok=True)
    os.makedirs("TF/overLimit", exist_ok=True)
    os.makedirs("TF/log", exist_ok=True)
    os.makedirs("TF/hideData", exist_ok=True)

    # 创建GUI
    root = tk.Tk()
    app = PowerShellGUI(root)

    # 加载配置
    app.load_config_from_file()

    # 启动主循环
    root.mainloop()

    # 保存配置
    app.save_config_to_file()


if __name__ == "__main__":
    main()
