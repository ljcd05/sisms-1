#ifndef __SYSTICK_H
#define __SYSTICK_H

#include "gd32f4xx.h"

// 函数声明
void systick_init(void);
uint32_t get_tick(void);
void delay_ms(uint32_t ms);
void delay_us(uint32_t us);

#endif


