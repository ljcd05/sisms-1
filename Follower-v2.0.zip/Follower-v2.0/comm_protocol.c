#include "comm_protocol.h"
#include "gd32f4xx_usart.h"
#include "system_config.h"
#include "oled.h"
#include "rtc.h"
#include "adc.h"
#include <stdio.h>
#include <string.h>
#include <stddef.h>

// 全局变量
uint8_t oled_display_mode = OLED_MODE_DISCONNECTED;

// 通信初始化
void comm_init(void)
{
    // 使能USART时钟和GPIO时钟
    rcu_periph_clock_enable(RCU_USART0);
    rcu_periph_clock_enable(RCU_GPIOA);
    
    // 配置USART引脚 (PA9/PA10)
    gpio_af_set(GPIOA, GPIO_AF_7, GPIO_PIN_9 | GPIO_PIN_10);
    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_9 | GPIO_PIN_10);
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_9);
    
    // 配置USART参数
    usart_deinit(USART0);
    usart_baudrate_set(USART0, 115200);
    usart_word_length_set(USART0, USART_WL_8BIT);
    usart_stop_bit_set(USART0, USART_STB_1BIT);
    usart_parity_config(USART0, USART_PM_NONE);
    usart_hardware_flow_rts_config(USART0, USART_RTS_DISABLE);
    usart_hardware_flow_cts_config(USART0, USART_CTS_DISABLE);
    usart_receive_config(USART0, USART_RECEIVE_ENABLE);
    usart_transmit_config(USART0, USART_TRANSMIT_ENABLE);
    usart_enable(USART0);
    
    // 初始化OLED显示模式
    oled_display_mode = OLED_MODE_DISCONNECTED;
    update_oled_display(OLED_MODE_DISCONNECTED, NULL);
}

// 处理接收到的帧
void comm_process_frame(CommFrame *frame)
{
    CommFrame response;
    float voltage;
    RTC_Time time;
    
    // 参数检查
    if(frame == NULL) {
        return;
    }
    
    // 初始化响应帧
    memset(&response, 0, sizeof(CommFrame));
    response.cmd = frame->cmd;
    
    // 根据命令处理
    switch(frame->cmd) {
        case CMD_SYSTEM_CHECK:
            // 系统自检
            if(frame->len >= 2) {
                // 简单的回显测试数据
                response.len = 1;
                response.data[0] = 0x01; // 成功
                comm_send_frame(&response);
            } else {
                response.len = 1;
                response.data[0] = 0x00; // 失败
                comm_send_frame(&response);
            }
            break;
            
        case CMD_RTC_CONFIG:
            // 设置RTC时间
            if(frame->len >= 7) {
                // 从数据中提取时间
                time.year = frame->data[0] + 2000; // 年份偏移
                time.month = frame->data[1];
                time.day = frame->data[2];
                time.hour = frame->data[3];
                time.minute = frame->data[4];
                time.second = frame->data[5];
                time.week = frame->data[6];
                
                // 设置RTC时间
                bool result = rtc_set_time(&time);
                
                // 发送响应
                response.len = 1;
                response.data[0] = result ? 0x01 : 0x00;
                comm_send_frame(&response);
            } else {
                response.len = 1;
                response.data[0] = 0x00; // 失败
                comm_send_frame(&response);
            }
            break;
            
        case CMD_RTC_TIME:
            // 获取RTC时间
            if(rtc_get_time(&time)) {
                // 填充时间数据
                response.len = 7;
                response.data[0] = time.year - 2000; // 年份偏移
                response.data[1] = time.month;
                response.data[2] = time.day;
                response.data[3] = time.hour;
                response.data[4] = time.minute;
                response.data[5] = time.second;
                response.data[6] = time.week;
                comm_send_frame(&response);
            } else {
                response.len = 1;
                response.data[0] = 0x00; // 失败
                comm_send_frame(&response);
            }
            break;
            
        case CMD_OLED_UPDATE:
            // 更新OLED显示状态
            if(frame->len >= 1) {
                uint8_t mode = frame->data[0];
                
                // 更新OLED显示模式
                if(mode <= OLED_MODE_REALTIME) {
                    // 如果是实时数据模式，需要额外的数据
                    if(mode == OLED_MODE_REALTIME && frame->len >= 8) {
                        // 提取时间和电压数据
                        RTC_Time display_time;
                        display_time.hour = frame->data[1];
                        display_time.minute = frame->data[2];
                        display_time.second = frame->data[3];
                        
                        // 提取电压值（4字节浮点数）
                        float display_voltage;
                        memcpy(&display_voltage, &frame->data[4], 4);
                        
                        // 更新显示
                        update_oled_display(mode, &(struct {
                            RTC_Time time;
                            float voltage;
                        }){display_time, display_voltage});
                    } else {
                        // 其他模式不需要额外数据
                        update_oled_display(mode, NULL);
                    }
                    
                    // 保存当前模式
                    oled_display_mode = mode;
                    
                    // 发送成功响应
                    response.len = 1;
                    response.data[0] = 0x01; // 成功
                    comm_send_frame(&response);
                } else {
                    // 无效的模式
                    response.len = 1;
                    response.data[0] = 0x00; // 失败
                    comm_send_frame(&response);
                }
            } else {
                response.len = 1;
                response.data[0] = 0x00; // 失败
                comm_send_frame(&response);
            }
            break;
            
        case CMD_GET_SAMPLE:
            // 获取单次采样数据
            if(get_adc_value(&voltage)) {
                // 应用变比
                voltage = apply_ratio(voltage);
                
                // 检查是否超过阈值
                bool is_over_limit = check_over_limit(voltage);
                
                // 获取当前时间
                if(rtc_get_time(&time)) {
                    // 发送采样数据
                    response.len = 8;
                    // 时间数据
                    response.data[0] = time.hour;
                    response.data[1] = time.minute;
                    response.data[2] = time.second;
                    // 电压数据
                    memcpy(&response.data[3], &voltage, 4);
                    // 是否超限
                    response.data[7] = is_over_limit ? 0x01 : 0x00;
                    comm_send_frame(&response);
                    
                    // 如果处于采样模式，更新OLED显示
                    if(oled_display_mode == OLED_MODE_SAMPLING) {
                        update_oled_display(OLED_MODE_REALTIME, &(struct {
                            RTC_Time time;
                            float voltage;
                        }){time, voltage});
                    }
                } else {
                    response.len = 1;
                    response.data[0] = 0x00; // 失败
                    comm_send_frame(&response);
                }
            } else {
                response.len = 1;
                response.data[0] = 0x00; // 失败
                comm_send_frame(&response);
            }
            break;
            
        case CMD_START_SCAN:
            // 开始扫描
            is_scanning = true;
            scan_count = 0;
            scan_error_count = 0;
            last_scan_time = get_tick();
            
            // 更新OLED显示为采样模式
            update_oled_display(OLED_MODE_SAMPLING, NULL);
            oled_display_mode = OLED_MODE_SAMPLING;
            
            // 发送响应
            response.len = 1;
            response.data[0] = 0x01; // 成功
            comm_send_frame(&response);
            break;
            
        case CMD_STOP_SCAN:
            // 停止扫描
            is_scanning = false;
            
            // 更新OLED显示为空闲模式
            update_oled_display(OLED_MODE_IDLE, NULL);
            oled_display_mode = OLED_MODE_IDLE;
            
            // 发送响应
            response.len = 1;
            response.data[0] = 0x01; // 成功
            comm_send_frame(&response);
            break;
            
        default:
            // 未知命令
            response.len = 1;
            response.data[0] = 0x00; // 失败
            comm_send_frame(&response);
            break;
    }
}

// 发送采样数据
void comm_send_sample(float voltage, bool is_over_limit)
{
    CommFrame frame;
    RTC_Time time;
    
    // 获取当前时间
    if(!rtc_get_time(&time)) {
        return; // 获取时间失败
    }
    
    // 初始化帧
    memset(&frame, 0, sizeof(CommFrame));
    frame.cmd = CMD_GET_SAMPLE;
    
    // 填充采样数据
    frame.len = 8;
    // 时间数据
    frame.data[0] = time.hour;
    frame.data[1] = time.minute;
    frame.data[2] = time.second;
    // 电压数据
    memcpy(&frame.data[3], &voltage, 4);
    // 是否超限
    frame.data[7] = is_over_limit ? 0x01 : 0x00;
    
    // 发送帧
    comm_send_frame(&frame);
    
    // 如果处于采样模式，更新OLED显示
    if(oled_display_mode == OLED_MODE_SAMPLING) {
        update_oled_display(OLED_MODE_REALTIME, &(struct {
            RTC_Time time;
            float voltage;
        }){time, voltage});
    }
}

// 更新OLED显示
void update_oled_display(uint8_t mode, void *data)
{
    char line1[21] = {0};
    char line2[21] = {0};
    
    // 清空显示
    oled_clear();
    
    // 根据模式更新显示
    switch(mode) {
        case OLED_MODE_DISCONNECTED:
            // 未连接模式
            strcpy(line1, "disconnected");
            break;
            
        case OLED_MODE_IDLE:
            // 空闲模式
            strcpy(line1, "system idle");
            break;
            
        case OLED_MODE_SAMPLING:
            // 采样模式
            strcpy(line1, "system sampling");
            break;
            
        case OLED_MODE_REALTIME:
            // 实时数据显示
            if(data != NULL) {
                struct {
                    RTC_Time time;
                    float voltage;
                } *display_data = (struct {
                    RTC_Time time;
                    float voltage;
                } *)data;
                
                // 格式化时间
                sprintf(line1, "%02d:%02d:%02d", 
                        display_data->time.hour,
                        display_data->time.minute,
                        display_data->time.second);
                
                // 格式化电压
                sprintf(line2, "%.2f V", (double)display_data->voltage);
            }
            break;
            
        default:
            // 未知模式，显示错误信息
            strcpy(line1, "Error: Unknown mode");
            break;
    }
    
    // 更新OLED显示
    oled_write_string(0, 0, line1);
    if(line2[0] != '\0') {
        oled_write_string(0, 2, line2);
    }
}




