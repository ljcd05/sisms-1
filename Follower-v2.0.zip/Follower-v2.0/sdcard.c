#include "sdcard.h"
#include "diskio.h"
#include <string.h>

static uint8_t SD_Type = 0; // SD卡类型

// SPI初始化
void SD_SPI_Init(void)
{
    spi_parameter_struct spi_init_struct;
    
    // 初始化SPI引脚
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_SPI2);
    
    // 配置SPI引脚
    gpio_mode_set(GPIOB, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15);
    gpio_output_options_set(GPIOB, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15);
    gpio_af_set(GPIOB, GPIO_AF_6, GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15);
    
    // 配置CS引脚
    gpio_mode_set(GPIOB, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, GPIO_PIN_12);
    gpio_output_options_set(GPIOB, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_12);
    gpio_bit_set(GPIOB, GPIO_PIN_12);
    
    // 配置SPI参数
    spi_init_struct.device_mode = SPI_MASTER;
    spi_init_struct.trans_mode = SPI_TRANSMODE_FULLDUPLEX;
    spi_init_struct.frame_size = SPI_FRAMESIZE_8BIT;
    spi_init_struct.clock_polarity_phase = SPI_CK_PL_LOW_PH_1EDGE;
    spi_init_struct.nss = SPI_NSS_SOFT;
    spi_init_struct.prescale = SPI_PSC_256; // 初始低速
    spi_init_struct.endian = SPI_ENDIAN_MSB;
    
    spi_init(SPI2, &spi_init_struct);
    spi_enable(SPI2);
}

// SPI速度设置函数
void SD_SPI_SpeedLow(void)
{
    spi_parameter_struct spi_init_struct;
    
    spi_disable(SPI2);
    
    spi_init_struct.device_mode = SPI_MASTER;
    spi_init_struct.trans_mode = SPI_TRANSMODE_FULLDUPLEX;
    spi_init_struct.frame_size = SPI_FRAMESIZE_8BIT;
    spi_init_struct.clock_polarity_phase = SPI_CK_PL_LOW_PH_1EDGE;
    spi_init_struct.nss = SPI_NSS_SOFT;
    spi_init_struct.prescale = SPI_PSC_256; // 低速
    spi_init_struct.endian = SPI_ENDIAN_MSB;
    
    spi_init(SPI2, &spi_init_struct);
    spi_enable(SPI2);
}

void SD_SPI_SpeedHigh(void)
{
    spi_parameter_struct spi_init_struct;
    
    spi_disable(SPI2);
    
    spi_init_struct.device_mode = SPI_MASTER;
    spi_init_struct.trans_mode = SPI_TRANSMODE_FULLDUPLEX;
    spi_init_struct.frame_size = SPI_FRAMESIZE_8BIT;
    spi_init_struct.clock_polarity_phase = SPI_CK_PL_LOW_PH_1EDGE;
    spi_init_struct.nss = SPI_NSS_SOFT;
    spi_init_struct.prescale = SPI_PSC_4; // 高速
    spi_init_struct.endian = SPI_ENDIAN_MSB;
    
    spi_init(SPI2, &spi_init_struct);
    spi_enable(SPI2);
}

// SPI读写一个字节
uint8_t SD_SPI_ReadWriteByte(uint8_t data)
{
    while(RESET == spi_i2s_flag_get(SPI2, SPI_FLAG_TBE));
    spi_i2s_data_transmit(SPI2, data);
    
    while(RESET == spi_i2s_flag_get(SPI2, SPI_FLAG_RBNE));
    return (uint8_t)spi_i2s_data_receive(SPI2);
}

// 向SD卡发送命令
uint8_t SD_SendCmd(uint8_t cmd, uint32_t arg, uint8_t crc)
{
    uint8_t r1;
    uint8_t retry = 0;
    
    // 片选拉高，取消上次片选
    SD_CS_DISABLE();
    SD_SPI_ReadWriteByte(0xFF);
    
    // 片选有效
    SD_CS_ENABLE();
    
    // 发送命令包
    SD_SPI_ReadWriteByte(cmd | 0x40);  // 起始+命令
    SD_SPI_ReadWriteByte((uint8_t)(arg >> 24));   // 参数
    SD_SPI_ReadWriteByte((uint8_t)(arg >> 16));
    SD_SPI_ReadWriteByte((uint8_t)(arg >> 8));
    SD_SPI_ReadWriteByte((uint8_t)arg);
    SD_SPI_ReadWriteByte(crc);         // CRC
    
    // 等待响应，或超时退出
    while((r1 = SD_SPI_ReadWriteByte(0xFF)) == 0xFF)
    {
        retry++;
        if(retry > 200) break;
    }
    
    return r1;
}

// 等待SD卡回应
uint8_t SD_GetResponse(uint8_t response)
{
    uint16_t count = 0xFFF;
    
    while((SD_SPI_ReadWriteByte(0xFF) != response) && count)
    {
        count--;
    }
    
    if(count == 0)
        return 1; // 失败
    else
        return 0; // 成功
}

// 从SD卡读取一个数据包
uint8_t SD_RecvData(uint8_t *buf, uint16_t len)
{
    uint16_t i;
    
    if(SD_GetResponse(0xFE)) // 等待SD卡发回数据起始令牌0xFE
        return 1;
    
    // 开始接收数据
    for(i = 0; i < len; i++) {
        buf[i] = SD_SPI_ReadWriteByte(0xFF);
    }
    
    // 接收2个字节的CRC（丢弃）
    SD_SPI_ReadWriteByte(0xFF);
    SD_SPI_ReadWriteByte(0xFF);
    
    return 0; // 读取成功
}

// 向SD卡写入一个数据包
uint8_t SD_SendBlock(const uint8_t *buf, uint8_t cmd)
{
    uint16_t t;
    
    if(SD_GetResponse(0xFF)) return 1; // 等待准备就绪
    
    // 发送命令
    SD_SPI_ReadWriteByte(cmd);
    if(cmd != 0xFD) // 不是结束指令
    {
        // 发送数据
        for(t = 0; t < 512; t++) {
            SD_SPI_ReadWriteByte(buf[t]);
        }
        
        // 发送CRC（无意义）
        SD_SPI_ReadWriteByte(0xFF);
        SD_SPI_ReadWriteByte(0xFF);
        
        // 接收响应
        t = SD_SPI_ReadWriteByte(0xFF);
        if((t & 0x1F) != 0x05) return 2; // 响应错误
    }
    
    return 0; // 写入成功
}

// 检测SD卡是否存在
uint8_t SD_Detect(void)
{
    // 这里简化处理，假设SD卡总是存在
    // 实际应用中可以通过检测卡检测引脚来判断
    return SD_PRESENT;
}

// 初始化SD卡
uint8_t SD_Init(void)
{
    uint8_t r1;      // 存放SD卡的返回值
    uint16_t retry;  // 用来进行超时计数
    uint8_t buf[4];  
    uint16_t i;
    
    SD_SPI_Init();   // 初始化SPI
    
    // SD卡上电复位
    for(i = 0; i < 10; i++) SD_SPI_ReadWriteByte(0xFF); // 至少74个时钟
    
    retry = 20;
    do
    {
        r1 = SD_SendCmd(CMD0, 0, 0x95); // 发送CMD0，复位SD卡
    } while((r1 != 0x01) && retry--);
    
    SD_Type = 0; // 默认无卡
    
    if(r1 == 0x01) // SD卡进入IDLE状态
    {
        // 发送CMD8，检查SD卡版本
        if(SD_SendCmd(CMD8, 0x1AA, 0x87) == 0x01) // SD V2.0
        {
            // 接收CMD8的4字节响应
            for(i = 0; i < 4; i++) buf[i] = SD_SPI_ReadWriteByte(0xFF);
            
            if(buf[2] == 0x01 && buf[3] == 0xAA) // Check voltage support (2.7-3.6V)
            {
                // 等待退出IDLE状态
                retry = 0xFFF;
                do
                {
                    SD_SendCmd(CMD55, 0, 0x01);
                    r1 = SD_SendCmd(CMD41, 0x40000000, 0x01);
                } while(r1 && retry--);
                
                // 鉴别SD卡版本
                if(retry && SD_SendCmd(CMD58, 0, 0x01) == 0)
                {
                    // 接收OCR信息
                    for(i = 0; i < 4; i++) buf[i] = SD_SPI_ReadWriteByte(0xFF);
                    
                    // 检查CCS位
                    if(buf[0] & 0x40) SD_Type = SD_TYPE_V2HC; // 高容量卡
                    else SD_Type = SD_TYPE_V2;                // 标准V2.0卡
                }
            }
        }
        else // SD V1.x 或 MMC
        {
            SD_SendCmd(CMD55, 0, 0x01);
            r1 = SD_SendCmd(CMD41, 0, 0x01);
            
            if(r1 <= 1)
            {
                SD_Type = SD_TYPE_V1;
                retry = 0xFFF;
                
                // 等待退出IDLE状态
                do
                {
                    SD_SendCmd(CMD55, 0, 0x01);
                    r1 = SD_SendCmd(CMD41, 0, 0x01);
                } while(r1 && retry--);
            }
            else // MMC卡
            {
                SD_Type = SD_TYPE_MMC;
                retry = 0xFFF;
                
                // 等待退出IDLE状态
                do
                {
                    r1 = SD_SendCmd(CMD1, 0, 0x01);
                } while(r1 && retry--);
            }
            
            // 设置块大小为512
            if(retry == 0 || SD_SendCmd(CMD16, 512, 0x01) != 0) SD_Type = SD_TYPE_ERR;
        }
    }
    
    SD_CS_DISABLE();
    SD_SPI_SpeedHigh(); // 高速模式
    
    if(SD_Type) return 0; // 初始化成功
    else return 1;        // 初始化失败
}

// 读SD卡扇区
uint8_t SD_ReadDisk(uint8_t *buf, uint32_t sector, uint8_t cnt)
{
    uint8_t r1;
    
    // 检查卡类型
    if(SD_Type != SD_TYPE_V2HC) sector <<= 9; // 非高容量卡，将扇区转换为字节地址
    
    if(cnt == 1) // 单个sector
    {
        r1 = SD_SendCmd(CMD17, sector, 0x01); // 读命令
        if(r1 == 0) // 指令发送成功
        {
            r1 = SD_RecvData(buf, 512); // 接收512个字节
        }
    }
    else // 多个sector
    {
        r1 = SD_SendCmd(CMD18, sector, 0x01); // 连续读命令
        do
        {
            r1 = SD_RecvData(buf, 512); // 接收512个字节
            buf += 512;
        } while(--cnt && r1 == 0);
        
        SD_SendCmd(CMD12, 0, 0x01); // 发送停止命令
    }
    
    SD_CS_DISABLE();
    return r1;
}

// 写SD卡扇区
uint8_t SD_WriteDisk(uint8_t *buf, uint32_t sector, uint8_t cnt)
{
    uint8_t r1;
    
    // 检查卡类型
    if(SD_Type != SD_TYPE_V2HC) sector <<= 9; // 非高容量卡，将扇区转换为字节地址
    
    if(cnt == 1) // 单个sector
    {
        r1 = SD_SendCmd(CMD24, sector, 0x01); // 写命令
        if(r1 == 0) // 指令发送成功
        {
            r1 = SD_SendBlock(buf, 0xFE); // 写512个字节
        }
    }
    else // 多个sector
    {
        if(SD_Type != SD_TYPE_MMC)
        {
            SD_SendCmd(CMD55, 0, 0x01);
            SD_SendCmd(CMD23, cnt, 0x01); // 设置块数量
        }
        
        r1 = SD_SendCmd(CMD25, sector, 0x01); // 连续写命令
        if(r1 == 0)
        {
            do
            {
                r1 = SD_SendBlock(buf, 0xFC); // 写512个字节
                buf += 512;
            } while(--cnt && r1 == 0);
            
            r1 = SD_SendBlock(0, 0xFD); // 结束传输
        }
    }
    
    SD_CS_DISABLE();
    return r1;
}

// 获取SD卡扇区数
uint32_t SD_GetSectorCount(void)
{
    uint8_t csd[16];
    uint32_t capacity;
    uint8_t n;
    uint16_t csize;
    
    // 读取CSD寄存器
    if(SD_SendCmd(CMD9, 0, 0x01) == 0 && SD_RecvData(csd, 16) == 0)
    {
        if((csd[0] & 0xC0) == 0x40) // V2.0卡
        {
            csize = csd[9] + ((uint16_t)csd[8] << 8) + 1;
            capacity = (uint32_t)csize << 10; // 扇区数 = (C_SIZE+1) * 1024
        }
        else // V1.0卡
        {
            n = (csd[5] & 15) + ((csd[10] & 128) >> 7) + ((csd[9] & 3) << 1) + 2;
            csize = (csd[8] >> 6) + ((uint16_t)csd[7] << 2) + ((uint16_t)(csd[6] & 3) << 10) + 1;
            capacity = (uint32_t)csize << (n - 9); // 扇区数 = (C_SIZE+1) * 2^(C_SIZE_MULT+2+READ_BL_LEN-9)
        }
    }
    else
    {
        capacity = 0;
    }
    
    SD_CS_DISABLE();
    return capacity;
}

// FatFs磁盘接口函数 - 获取磁盘状态
DSTATUS MMC_disk_status(void)
{
    if(SD_Type == SD_TYPE_ERR || SD_Detect() != SD_PRESENT)
        return STA_NOINIT;
    else
        return 0; // 状态正常
}

// FatFs磁盘接口函数 - 初始化磁盘
DSTATUS MMC_disk_initialize(void)
{
    if(SD_Init() == 0)
        return 0; // 初始化成功
    else
        return STA_NOINIT; // 初始化失败
}

// FatFs磁盘接口函数 - 读扇区
DRESULT MMC_disk_read(BYTE *buff, LBA_t sector, UINT count)
{
    if(SD_ReadDisk(buff, sector, count) == 0)
        return RES_OK;
    else
        return RES_ERROR;
}

// FatFs磁盘接口函数 - 写扇区
DRESULT MMC_disk_write(const BYTE *buff, LBA_t sector, UINT count)
{
    if(SD_WriteDisk((uint8_t*)buff, sector, count) == 0)
        return RES_OK;
    else
        return RES_ERROR;
}

// FatFs磁盘接口函数 - 其他控制
DRESULT MMC_disk_ioctl(BYTE cmd, void *buff)
{
    DRESULT res = RES_ERROR;
    
    switch(cmd)
    {
        case CTRL_SYNC: // 同步
            SD_CS_ENABLE();
            if(SD_GetResponse(0xFF) == 0)
                res = RES_OK;
            break;
        
        case GET_SECTOR_COUNT: // 获取扇区数
            *(DWORD*)buff = SD_GetSectorCount();
            res = RES_OK;
            break;
        
        case GET_SECTOR_SIZE: // 获取扇区大小
            *(WORD*)buff = 512; // 固定为512字节
            res = RES_OK;
            break;
        
        case GET_BLOCK_SIZE: // 获取擦除块大小
            *(DWORD*)buff = 8; // 默认为8个扇区
            res = RES_OK;
            break;
        
        default:
            res = RES_PARERR;
            break;
    }
    
    SD_CS_DISABLE();
    return res;
}





