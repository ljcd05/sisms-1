#include "system_config.h"
#include "fatfs_app.h"
#include "ff.h"  // 添加FatFS头文件
#include <string.h>
#include <stdio.h>
#include <stddef.h>

// 系统配置全局变量
SystemConfig sys_config;

// 扫描相关变量
uint32_t scan_count = 0;
uint32_t scan_error_count = 0;
bool is_scanning = false;
uint32_t scan_interval = 1000; // 默认扫描间隔1秒
uint32_t last_scan_time = 0;

// 重置系统配置为默认值
void reset_system_config(void)
{
    // 设置默认配置
    sys_config.ratio = 1.0f;
    sys_config.limit = 5.0f;
    sys_config.hide_mode = 0;
    
    // 保存默认配置
    save_system_config();
}

// 从Flash加载系统配置
bool load_system_config(void)
{
    // 从配置文件读取
    FIL file;
    FRESULT res;
    UINT br;
    
    // 打开配置文件
    res = f_open(&file, "config.dat", FA_READ);
    if(res != FR_OK) {
        return false;
    }
    
    // 读取配置数据
    res = f_read(&file, &sys_config, sizeof(SystemConfig), &br);
    
    // 关闭文件
    f_close(&file);
    
    // 检查读取结果
    if(res != FR_OK || br != sizeof(SystemConfig)) {
        return false;
    }
    
    return true;
}

// 保存系统配置到Flash
bool save_system_config(void)
{
    // 保存到配置文件
    FIL file;
    FRESULT res;
    UINT bw;
    
    // 打开配置文件
    res = f_open(&file, "config.dat", FA_CREATE_ALWAYS | FA_WRITE);
    if(res != FR_OK) {
        return false;
    }
    
    // 写入配置数据
    res = f_write(&file, &sys_config, sizeof(SystemConfig), &bw);
    
    // 关闭文件
    f_close(&file);
    
    // 检查写入结果
    if(res != FR_OK || bw != sizeof(SystemConfig)) {
        return false;
    }
    
    return true;
}

// 应用变比
float apply_ratio(float voltage)
{
    return voltage * sys_config.ratio;
}

// 检查是否超过阈值
bool check_over_limit(float voltage)
{
    return voltage > sys_config.limit;
}

// 检查扫描按钮
void check_scan_button(void)
{
    // 读取扫描按钮状态
    bool button_pressed = gpio_input_bit_get(GPIOB, GPIO_PIN_0) == 0;
    
    // 按钮按下时切换扫描状态
    static bool last_button_state = false;
    if(button_pressed && !last_button_state) {
        // 切换扫描状态
        is_scanning = !is_scanning;
        
        // 如果开始扫描，重置计数器
        if(is_scanning) {
            scan_count = 0;
            scan_error_count = 0;
            last_scan_time = get_tick();
        }
    }
    
    // 更新按钮状态
    last_button_state = button_pressed;
}



