
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'Follower-v2.0' 
 * Target:  'Target 1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "gd32f4xx.h"

/* GigaDevice::Device:StdPeripherals:GPIO@3.3.0 */
#define RTE_DEVICE_STDPERIPHERALS_GPIO
/* GigaDevice::Device:StdPeripherals:I2C@3.3.0 */
#define RTE_DEVICE_STDPERIPHERALS_I2C
/* GigaDevice::Device:StdPeripherals:IPA@3.3.0 */
#define RTE_DEVICE_STDPERIPHERALS_IPA
/* GigaDevice::Device:StdPeripherals:IREF@3.3.0 */
#define RTE_DEVICE_STDPERIPHERALS_IREF
/* GigaDevice::Device:StdPeripherals:MISC@3.3.0 */
#define RTE_DEVICE_STDPERIPHERALS_MISC
/* GigaDevice::Device:StdPeripherals:PMU@3.3.0 */
#define RTE_DEVICE_STDPERIPHERALS_PMU
/* GigaDevice::Device:StdPeripherals:RCU@3.3.0 */
#define RTE_DEVICE_STDPERIPHERALS_RCU
/* GigaDevice::Device:StdPeripherals:RTC@3.3.0 */
#define RTE_DEVICE_STDPERIPHERALS_RTC
/* GigaDevice::Device:StdPeripherals:SDIO@3.3.0 */
#define RTE_DEVICE_STDPERIPHERALS_SDIO


#endif /* RTE_COMPONENTS_H */
