#include "delay.h"

static uint8_t fac_us = 0;
static uint16_t fac_ms = 0;

// 初始化延时函数
void delay_init(void)
{
    // 选择外部时钟 HCLK/8
    SysTick->CTRL &= ~SysTick_CTRL_CLKSOURCE_Msk;
    fac_us = (uint8_t)(SystemCoreClock / 8000000);
    fac_ms = (uint16_t)(fac_us * 1000);
}

// 微秒延时
void delay_us(uint32_t us)
{
    uint32_t temp;
    SysTick->LOAD = us * fac_us;
    SysTick->VAL = 0x00;
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;
    
    do {
        temp = SysTick->CTRL;
    } while((temp & 0x01) && !(temp & (1 << 16)));
    
    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
    SysTick->VAL = 0x00;
}

// 毫秒延时
void delay_ms(uint32_t ms)
{
    uint32_t i;
    for(i = 0; i < ms; i++)
    {
        delay_us(1000);
    }
}

