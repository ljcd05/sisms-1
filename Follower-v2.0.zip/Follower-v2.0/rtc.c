#include "rtc.h"
#include "gd32f4xx.h"
#include "gd32f4xx_rtc.h"
#include "gd32f4xx_bkp.h"  // 添加备份域头文件
#include <stdbool.h>
#include <stddef.h>

// RTC初始化 - 重命名以避免与库冲突
bool rtc_init_custom(void)
{
    // 使能PMU和RTC时钟
    rcu_periph_clock_enable(RCU_PMU);
    rcu_periph_clock_enable(RCU_RTC);
    rcu_periph_clock_enable(RCU_BKP);  // 使用RCU_BKP而不是RCU_BKPI
    
    // 使能PMU访问
    pmu_backup_write_enable();
    
    // 复位备份域
    bkp_deinit();
    
    // 选择RTC时钟源为LXTAL
    rcu_osci_on(RCU_LXTAL);
    rcu_osci_stab_wait(RCU_LXTAL);
    rcu_rtc_clock_config(RCU_RTCSRC_LXTAL);
    
    // 配置RTC参数
    rtc_parameter_struct rtc_initpara;
    rtc_initpara.factor_asyn = 0x7F;
    rtc_initpara.factor_syn = 0xFF;
    rtc_initpara.year = 0x22;  // 2022年
    rtc_initpara.month = 0x01; // 1月
    rtc_initpara.date = 0x01;  // 1日
    rtc_initpara.day_of_week = RTC_MONDAY;
    rtc_initpara.hour = 0x00;  // 0时
    rtc_initpara.minute = 0x00; // 0分
    rtc_initpara.second = 0x00; // 0秒
    rtc_initpara.display_format = RTC_24HOUR;
    rtc_initpara.am_pm = RTC_AM;
    
    // 初始化RTC - 使用rtc_init函数而不是自定义函数
    if(ERROR == rtc_init(&rtc_initpara)) {
        return false;
    }
    
    return true;
}

// 设置RTC时间
bool rtc_set_time(RTC_Time *time)
{
    rtc_parameter_struct rtc_time;
    
    // 参数检查
    if(time == NULL || 
       time->year < 2000 || time->year > 2099 ||
       time->month < 1 || time->month > 12 ||
       time->day < 1 || time->day > 31 ||
       time->hour > 23 || time->minute > 59 || time->second > 59) {
        return false;
    }
    
    // 转换为rtc_parameter_struct格式
    rtc_time.year = time->year - 2000; // 转换为两位数年份
    rtc_time.month = time->month;
    rtc_time.date = time->day;
    
    // 计算星期几 (简化算法)
    uint8_t day_of_week = 1; // 默认星期一
    rtc_time.day_of_week = day_of_week;
    
    rtc_time.hour = time->hour;
    rtc_time.minute = time->minute;
    rtc_time.second = time->second;
    rtc_time.display_format = RTC_24HOUR;
    rtc_time.am_pm = RTC_AM;
    
    // 使能PMU访问
    pmu_backup_write_enable();
    
    // 初始化RTC - 使用rtc_init函数
    if(ERROR == rtc_init(&rtc_time)) {
        return false;
    }
    
    return true;
}

// 获取RTC时间
bool rtc_get_time(RTC_Time *time)
{
    // 参数检查
    if(time == NULL) {
        return false;
    }
    
    // 读取RTC时间 - 使用rtc_date_get和rtc_time_get函数
    uint32_t date = rtc_date_get();
    uint32_t rtc_time = rtc_time_get();
    
    time->year = rtc_bcd2_to_dec((date >> 16) & 0xFF) + 2000;
    time->month = rtc_bcd2_to_dec((date >> 8) & 0x1F);
    time->day = rtc_bcd2_to_dec(date & 0x3F);
    time->hour = rtc_bcd2_to_dec((rtc_time >> 16) & 0x3F);
    time->minute = rtc_bcd2_to_dec((rtc_time >> 8) & 0x7F);
    time->second = rtc_bcd2_to_dec(rtc_time & 0x7F);
    
    return true;
}

// BCD码转十进制
static uint8_t rtc_bcd2_to_dec(uint8_t val)
{
    return ((val >> 4) * 10 + (val & 0x0F));
}

// 十进制转BCD码
static uint8_t rtc_dec_to_bcd2(uint8_t val)
{
    return (((val / 10) << 4) + (val % 10));
}



