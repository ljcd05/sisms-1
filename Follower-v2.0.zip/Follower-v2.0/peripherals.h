#ifndef __PERIPHERALS_H
#define __PERIPHERALS_H

#include "gd32f4xx.h"
#include <stdbool.h>
#include <stddef.h>

// 按键定义
#define KEY_COUNT           5  // 更新为5以保持一致性
#define KEY_LONG_PRESS_TIME 1000  // 长按时间阈值(ms)

// 函数声明
void gpio_init(void);
void key_scan(void);
bool key_is_pressed(uint8_t key);
void key_short_press_handler(uint8_t key);
void key_long_press_handler(uint8_t key);

// 外部变量声明
extern GPIO_TypeDef* key_ports[KEY_COUNT];
extern uint16_t key_pins[KEY_COUNT];
extern bool key_pressed[KEY_COUNT];
extern uint32_t key_press_time[KEY_COUNT];

#endif

