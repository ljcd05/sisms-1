/* 取消注释以启用GD32F470 */
#define GD32F470