#ifndef __ADC_H
#define __ADC_H

#include "gd32f4xx.h"
#include <stdbool.h>
#include <stddef.h>

// 函数声明
void adc_init_custom(void);
bool get_adc_value(float *voltage);

#endif





