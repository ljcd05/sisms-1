#ifndef __COMM_PROTOCOL_H
#define __COMM_PROTOCOL_H

#include "gd32f4xx.h"
#include <stdbool.h>

// 帧格式定义
#define FRAME_HEADER        0xAA
#define FRAME_FOOTER        0x55
#define FRAME_MAX_DATA_LEN  64

// 命令定义
#define CMD_SYSTEM_CHECK    0x01  // 系统自检
#define CMD_RTC_CONFIG      0x02  // RTC配置
#define CMD_RTC_TIME        0x03  // 获取RTC时间
#define CMD_OLED_UPDATE     0x20  // OLED更新
#define CMD_GET_SAMPLE      0x11  // 获取采样
#define CMD_START_SCAN      0x0B  // 开始扫描
#define CMD_STOP_SCAN       0x0C  // 停止扫描

// OLED显示模式
#define OLED_MODE_DISCONNECTED  0  // 未连接
#define OLED_MODE_IDLE          1  // 空闲模式
#define OLED_MODE_SAMPLING      2  // 采样模式
#define OLED_MODE_REALTIME      3  // 实时数据显示

// 帧结构体
typedef struct {
    uint8_t header;
    uint8_t cmd;
    uint8_t len;
    uint8_t data[FRAME_MAX_DATA_LEN];
    uint8_t checksum;
    uint8_t footer;
} CommFrame;

// 函数声明
void comm_init(void);
bool comm_receive_frame(CommFrame *frame);
bool comm_send_frame(CommFrame *frame);
void comm_process_frame(CommFrame *frame);
void comm_send_status(void);
void comm_send_sample(float voltage, bool is_over_limit);
void update_oled_display(uint8_t mode, void *data);

// 全局变量
extern uint8_t oled_display_mode;

#endif





