#include "gd32f4xx.h"
#include "gd32f4xx_usart.h"
#include "gd32f4xx_adc.h"
#include "gd32f4xx_timer.h"
#include "gd32f4xx_rtc.h"
#include "fatfs_app.h"
#include "comm_protocol.h"
#include "system_config.h"
#include "delay.h"
#include "peripherals.h"
#include "systick.h"
#include "adc.h"
#include "rtc.h"
#include "oled.h"  // 添加OLED头文件包含
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

// 函数声明
void system_init(void);
void gpio_init(void);
void usart_init(void);
void app_timer_init(void); // 重命名为app_timer_init避免冲突
void process_communication(void);
void process_scanning(void);
void test_uart_communication(void); // 添加函数原型声明
void test_oled_display(void);       // 添加OLED测试函数原型声明

// OLED显示测试函数
void test_oled_display(void)
{
    // 初始化OLED并进行自检
    if(oled_self_test()) {
        // 自检成功，显示系统信息
        delay_ms(2000);  // 显示自检内容2秒
        
        oled_clear();
        oled_write_string(0, 0, "System Ready");
        oled_write_string(0, 2, "ADC: Ready");
        oled_write_string(0, 3, "SD Card: Ready");
        oled_write_string(0, 4, "RTC: Ready");
        
        // 显示系统参数
        char buf[20];
        sprintf(buf, "Ratio: %.2f", (double)sys_config.ratio);
        oled_write_string(0, 5, buf);
        
        // 显示其他系统信息
        oled_write_string(0, 6, "Scan Interval: 1s");
        oled_write_string(0, 7, "Threshold: 5.00V");
        
        delay_ms(5000);  // 显示系统信息5秒
    }
    else {
        // 自检失败，显示错误信息
        oled_clear();
        oled_write_string(0, 0, "OLED Self Test Failed");
        delay_ms(3000);  // 显示错误信息3秒
    }
}

// 处理通信函数
void process_communication(void)
{
    CommFrame frame;
    
    // 接收并处理帧
    if(comm_receive_frame(&frame)) {
        comm_process_frame(&frame);
    }
}

// 主函数 - 保留一个main函数定义，删除重复的定义
int main(void)
{
    // 系统初始化
    system_init();
    
    // 初始化文件系统
    if(!FATFS_Init()) {
        // 文件系统初始化失败，点亮错误指示灯
        gpio_bit_reset(GPIOC, GPIO_PIN_13);
        while(1);
    }
    
    // 加载系统配置
    if(!load_system_config()) {
        // 配置加载失败，使用默认配置
        reset_system_config();
    }
    
    // 记录系统启动日志
    RTC_Time time;
    if(rtc_get_time(&time)) {
        FATFS_WriteLog("System started", &time);
    }
    
    // 初始化OLED
    if(!oled_init()) {
        // OLED初始化失败，记录日志
        if(rtc_get_time(&time)) {
            FATFS_WriteLog("OLED init failed", &time);
        }
    } else {
        // OLED初始化成功，显示欢迎信息
        oled_clear();
        oled_write_string(0, 0, "System Ready");
        oled_write_string(0, 2, "Waiting for");
        oled_write_string(0, 3, "connection...");
    }
    
    // 测试串口通信
    test_uart_communication();
    
    // 测试OLED显示
    test_oled_display();
    
    // 初始化通信协议
    comm_init();
    
    // 主循环
    while(1) {
        // 处理通信
        process_communication();
        
        // 处理扫描
        process_scanning();
        
        // 检查扫描按钮
        check_scan_button();
        
        // 扫描所有按键
        key_scan();
    }
}

// 系统初始化
void system_init(void)
{
    // 初始化系统时钟
    SystemInit();
    
    // 初始化延时函数
    delay_init();
    
    // 初始化SysTick
    systick_init();
    
    // 初始化GPIO
    gpio_init();
    
    // 初始化USART
    usart_init();
    
    // 初始化ADC
    adc_init();
    
    // 初始化RTC
    rtc_init_custom();
    
    // 初始化定时器
    app_timer_init();
    
    // 初始化通信协议
    comm_init();
}

// GPIO初始化
void gpio_init(void)
{
    // 使能GPIO时钟
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_GPIOC);
    rcu_periph_clock_enable(RCU_GPIOE);
    
    // 配置LED1引脚（PA1）
    gpio_mode_set(GPIOA, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GPIO_PIN_1);
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_1);
    gpio_bit_set(GPIOA, GPIO_PIN_1); // 默认熄灭
    
    // 配置LED2引脚（PC3）
    gpio_mode_set(GPIOC, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GPIO_PIN_3);
    gpio_output_options_set(GPIOC, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_3);
    gpio_bit_set(GPIOC, GPIO_PIN_3); // 默认熄灭
    
    // 配置KEY1按钮引脚（PB10）
    gpio_mode_set(GPIOB, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, GPIO_PIN_10);
    
    // 配置KEY2按钮引脚（PB11）
    gpio_mode_set(GPIOB, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, GPIO_PIN_11);
    
    // 配置KEY3按钮引脚（PE15）
    gpio_mode_set(GPIOE, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, GPIO_PIN_15);
    
    // 配置KEY4按钮引脚（PE14）
    gpio_mode_set(GPIOE, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, GPIO_PIN_14);
    
    // 配置KEY5按钮引脚（PE13）
    gpio_mode_set(GPIOE, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, GPIO_PIN_13);
}

// USART初始化
void usart_init(void)
{
    // 使能USART时钟和GPIO时钟
    rcu_periph_clock_enable(RCU_USART0);
    rcu_periph_clock_enable(RCU_GPIOA);
    
    // TX (PA9) 配置为复用推挽输出
    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_9);
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_9);
    gpio_af_set(GPIOA, GPIO_AF_7, GPIO_PIN_9);  // 复用功能 AF7

    // RX (PA10) 配置为浮空输入
    gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_NONE, GPIO_PIN_10);
    gpio_af_set(GPIOA, GPIO_AF_7, GPIO_PIN_10);
    
    // 配置USART参数
    usart_deinit(USART0);
    usart_baudrate_set(USART0, 115200);
    usart_word_length_set(USART0, USART_WL_8BIT);
    usart_stop_bit_set(USART0, USART_STB_1BIT);
    usart_parity_config(USART0, USART_PM_NONE);
    usart_hardware_flow_rts_config(USART0, USART_RTS_DISABLE);
    usart_hardware_flow_cts_config(USART0, USART_CTS_DISABLE);
    usart_receive_config(USART0, USART_RECEIVE_ENABLE);
    usart_transmit_config(USART0, USART_TRANSMIT_ENABLE);
    
    // 配置USART中断
    usart_interrupt_enable(USART0, USART_INT_RBNE);
    nvic_irq_enable(USART0_IRQn, 0, 0);
    
    // 使能USART
    usart_enable(USART0);
}

// 定时器初始化（用于扫描间隔）- 重命名为app_timer_init避免冲突
void app_timer_init(void)
{
    // 使能定时器时钟
    rcu_periph_clock_enable(RCU_TIMER1);
    
    // 配置定时器
    timer_deinit(TIMER1);
    
    timer_parameter_struct timer_initpara;
    timer_initpara.prescaler = 10800 - 1;  // 108MHz / 10800 = 10KHz
    timer_initpara.alignedmode = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection = TIMER_COUNTER_UP;
    timer_initpara.period = 10000 - 1;     // 10KHz / 10000 = 1Hz (1s)
    timer_initpara.clockdivision = TIMER_CKDIV_DIV1;
    timer_initpara.repetitioncounter = 0;
    timer_init(TIMER1, &timer_initpara);
    
    // 配置定时器中断
    timer_interrupt_enable(TIMER1, TIMER_INT_UP);
    nvic_irq_enable(TIMER1_IRQn, 1, 0);
    
    // 默认不启动定时器，等待扫描命令
    timer_disable(TIMER1);
}

// 处理通信
void process_communication(void)
{
    CommFrame frame;
    
    // 接收并处理帧
    if(comm_receive_frame(&frame)) {
        comm_process_frame(&frame);
    }
}

// 处理扫描
void process_scanning(void)
{
    uint32_t current_time = get_tick();
    
    // 如果正在扫描，且不使用定时器中断方式，则在主循环中处理
    if(is_scanning && (current_time - last_scan_time >= scan_interval)) {
        float voltage;
        RTC_Time time;
        bool is_over_limit;
        char log_message[50];
        
        // 读取ADC值 - 使用bool返回类型
        if(get_adc_value(&voltage)) {
            // 应用变比
            voltage = apply_ratio(voltage);
            
            // 检查是否超过阈值
            is_over_limit = check_over_limit(voltage);
            
            // 获取当前时间 - 使用bool返回类型
            if(rtc_get_time(&time)) {
                // 保存采样数据
                if(FATFS_SaveSampleData(voltage, &time, is_over_limit)) {
                    scan_count++;
                    
                    // 如果超过阈值，记录日志
                    if(is_over_limit) {
                        sprintf(log_message, "Voltage over limit: %.2f V", (double)voltage);
                        FATFS_WriteLog(log_message, &time);
                        
                        // 点亮警告LED
                        gpio_bit_reset(GPIOC, GPIO_PIN_13);
                    }
                    else {
                        // 熄灭警告LED
                        gpio_bit_set(GPIOC, GPIO_PIN_13);
                    }
                    
                    // 更新OLED显示
                    if(oled_display_mode == OLED_MODE_SAMPLING) {
                        update_oled_display(OLED_MODE_REALTIME, &(struct {
                            RTC_Time time;
                            float voltage;
                        }){time, voltage});
                    }
                }
                else {
                    scan_error_count++;
                }
            }
            else {
                scan_error_count++;
            }
        }
        else {
            scan_error_count++;
        }
        
        // 更新上次扫描时间
        last_scan_time = current_time;
    }
}

// 定时器1中断处理函数（用于定时扫描）
void TIMER1_IRQHandler(void)
{
    if(timer_interrupt_flag_get(TIMER1, TIMER_INT_FLAG_UP) != RESET) {
        // 清除中断标志
        timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_UP);
        
        // 如果正在扫描，执行扫描操作
        if(is_scanning) {
            float voltage;
            
            // 读取ADC值 - 使用bool返回类型
            if(get_adc_value(&voltage)) {
                // 应用变比
                voltage = apply_ratio(voltage);
                
                // 检查是否超过阈值
                bool is_over_limit = check_over_limit(voltage);
                
                // 获取当前时间 - 使用bool返回类型
                RTC_Time time;
                if(rtc_get_time(&time)) {
                    // 保存采样数据
                    if(FATFS_SaveSampleData(voltage, &time, is_over_limit)) {
                        scan_count++;
                        
                        // 如果超过阈值，记录日志
                        if(is_over_limit) {
                            char log_message[50];
                            sprintf(log_message, "Voltage over limit: %.2f V", (double)voltage);
                            FATFS_WriteLog(log_message, &time);
                            
                            // 点亮警告LED
                            gpio_bit_reset(GPIOC, GPIO_PIN_13);
                        }
                        else {
                            // 熄灭警告LED
                            gpio_bit_set(GPIOC, GPIO_PIN_13);
                        }
                        
                        // 更新OLED显示
                        if(oled_display_mode == OLED_MODE_SAMPLING) {
                            update_oled_display(OLED_MODE_REALTIME, &(struct {
                                RTC_Time time;
                                float voltage;
                            }){time, voltage});
                        }
                    }
                    else {
                        scan_error_count++;
                    }
                }
                else {
                    scan_error_count++;
                }
            }
            else {
                scan_error_count++;
            }
        }
    }
}

// 删除以下重复定义的函数:
// 1. rtc_get_time - 已在rtc.c中定义
// 2. adc_init - 已在adc.c中定义
// 3. get_systick_value - 已在systick.c中定义
// 4. get_adc_value - 已在adc.c中定义
// 5. delay_ms - 已在delay.c中定义
// 6. SysTick_Handler - 已在systick.c中定义

// 文件系统初始化
bool fatfs_init(void)
{
    // 这里应该是文件系统初始化代码
    // 由于没有具体的文件系统实现，这里只返回成功
    return true;
}

// 保存配置到INI文件
bool save_config_to_ini(float ratio, float limit, uint8_t log_id)
{
    (void)ratio;
    (void)limit;
    (void)log_id;
    
    // 这里应该是保存配置到INI文件的代码
    // 由于没有具体的文件系统实现，这里只返回成功
    return true;
}

// 从INI文件读取配置
bool read_config_from_ini(float *ratio, float *limit, uint8_t *log_id)
{
    // 这里应该是从INI文件读取配置的代码
    // 由于没有具体的文件系统实现，这里只返回失败
    return false;
}

// 保存采样数据
bool save_sample_data(float voltage, RTC_Time *time, bool is_over_limit, float limit, bool hide_mode)
{
    // 这里应该是保存采样数据到文件的代码
    // 由于没有具体的文件系统实现，这里只返回成功
    return true;
}

// 写日志
bool write_log(const char *message, uint8_t *log_id)
{
    // 这里应该是写日志到文件的代码
    // 由于没有具体的文件系统实现，这里只返回成功
    return true;
}

// 获取系统tick计数
uint32_t get_tick_count(void)
{
    return (uint32_t)systick_get_value();
}

// 系统tick配置
void systick_config(void)
{
    // 配置SysTick为1ms中断
    if(SysTick_Config(SystemCoreClock / 1000)) {
        // 配置失败
        while(1);
    }
    
    // 设置SysTick中断优先级
    NVIC_SetPriority(SysTick_IRQn, 0x00);
}

// SysTick中断处理函数
// void SysTick_Handler(void)
// {
//     // 更新系统滴答计数器
//     systick_flag_set();
// }

// 测试串口通信
void test_uart_communication(void)
{
    // 创建测试帧
    CommFrame test_frame;
    test_frame.header = FRAME_HEADER;
    test_frame.cmd = CMD_TEST;
    test_frame.len = 2;
    test_frame.data[0] = 0xAA;
    test_frame.data[1] = 0x55;
    test_frame.checksum = 0; // 会在发送函数中计算
    test_frame.tail = FRAME_TAIL;
    
    // 发送测试帧
    comm_send_frame(&test_frame);
    
    // 延时一段时间
    delay_ms(1000);
}

// OLED显示测试函数
void test_oled_display(void)
{
    // 初始化OLED并进行自检
    if(oled_self_test()) {
        // 自检成功，显示系统信息
        delay_ms(2000);  // 显示自检内容2秒
        
        oled_clear();
        oled_write_string(0, 0, "System Ready");
        oled_write_string(0, 2, "ADC: Ready");
        oled_write_string(0, 3, "SD Card: Ready");
        oled_write_string(0, 4, "RTC: Ready");
        
        // 显示系统参数
        char buf[20];
        sprintf(buf, "Ratio: %.2f", (double)sys_config.ratio);
        oled_write_string(0, 5, buf);
        
        // 显示其他系统信息
        oled_write_string(0, 6, "Scan Interval: 1s");
        oled_write_string(0, 7, "Threshold: 5.00V");
        
        delay_ms(5000);  // 显示系统信息5秒
    }
    else {
        // 自检失败，显示错误信息
        oled_clear();
        oled_write_string(0, 0, "OLED Self Test Failed");
        delay_ms(3000);  // 显示错误信息3秒
    }
}

// 在main函数中添加OLED显示测试
int main(void)
{
    // 系统初始化
    system_init();
    
    // 初始化文件系统
    if(!FATFS_Init()) {
        // 文件系统初始化失败，点亮错误指示灯
        gpio_bit_reset(GPIOC, GPIO_PIN_13);
        while(1);
    }
    
    // 加载系统配置
    if(!load_system_config()) {
        // 配置加载失败，使用默认配置
        reset_system_config();
    }
    
    // 记录系统启动日志
    RTC_Time time;
    if(rtc_get_time(&time)) {
        FATFS_WriteLog("System started", &time);
    }
    
    // 测试串口通信
    test_uart_communication();
    
    // 测试OLED显示
    test_oled_display();
    
    // 设置OLED为未连接状态
    update_oled_display(OLED_MODE_DISCONNECTED, NULL);
    
    // 主循环
    while(1) {
        // 处理通信
        process_communication();
        
        // 处理扫描
        process_scanning();
        
        // 检查扫描按钮
        check_scan_button();
        
        // 扫描所有按键
        key_scan();
    }
}





