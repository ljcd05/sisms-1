#include "adc.h"
#include "gd32f4xx_adc.h"
#include "delay.h"
#include <stdbool.h>
#include <stddef.h>

// ADC初始化
void adc_init_custom(void)
{
    // 使能ADC时钟和GPIO时钟
    rcu_periph_clock_enable(RCU_ADC0);
    rcu_periph_clock_enable(RCU_GPIOA);
    
    // 配置ADC时钟
    adc_clock_config(ADC_ADCCK_PCLK2_DIV8);
    
    // 配置ADC引脚 (PA1)
    gpio_mode_set(GPIOA, GPIO_MODE_ANALOG, GPIO_PUPD_NONE, GPIO_PIN_1);
    
    // 复位ADC
    adc_deinit();
    
    // 配置ADC参数
    adc_resolution_config(ADC0, ADC_RESOLUTION_12B);
    adc_data_alignment_config(ADC0, ADC_DATAALIGN_RIGHT);
    adc_channel_length_config(ADC0, ADC_ROUTINE_CHANNEL, 1);
    adc_routine_channel_config(ADC0, 0, ADC_CHANNEL_1, ADC_SAMPLETIME_15);
    adc_external_trigger_config(ADC0, ADC_ROUTINE_CHANNEL, EXTERNAL_TRIGGER_DISABLE);
    
    // 启用ADC
    adc_enable(ADC0);
    
    // 等待ADC稳定
    delay_ms(1);
}

// 获取ADC值
bool get_adc_value(float *voltage)
{
    uint16_t adc_value;
    uint32_t timeout = 1000; // 超时计数
    
    // 参数检查
    if(!voltage) {
        return false;
    }
    
    // 启动ADC转换
    adc_software_trigger_enable(ADC0, ADC_ROUTINE_CHANNEL);
    
    // 等待转换完成
    while(!adc_flag_get(ADC0, ADC_FLAG_EOC) && timeout > 0) {
        timeout--;
        delay_us(1);
    }
    
    if(timeout == 0) {
        return false; // 转换超时
    }
    
    // 读取ADC值
    adc_value = adc_routine_data_read(ADC0);
    
    // 转换为电压值 (12位ADC, 参考电压3.3V)
    *voltage = (float)adc_value * 3.3f / 4096.0f;
    
    return true;
}







