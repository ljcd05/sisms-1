#include "oled.h"
#include "gd32f4xx_i2c.h"
#include "delay.h"
#include <string.h>
#include <stddef.h>

// OLED显示缓冲区
static uint8_t oled_buffer[OLED_PAGE_NUM][OLED_WIDTH];

// 6x8字体数据
static const uint8_t font6x8[][6] = {
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, // 空格
    // 其他字符数据...
};

// I2C写命令
static bool oled_write_cmd(uint8_t cmd)
{
    // 等待I2C空闲
    while(i2c_flag_get(I2C0, I2C_FLAG_BUSY));
    
    // 发送起始信号
    i2c_start_on_bus(I2C0);
    while(!i2c_flag_get(I2C0, I2C_FLAG_SBSEND));
    
    // 发送设备地址
    i2c_master_addressing(I2C0, OLED_ADDRESS, I2C_TRANSMITTER);
    while(!i2c_flag_get(I2C0, I2C_FLAG_ADDSEND));
    i2c_flag_clear(I2C0, I2C_FLAG_ADDSEND);
    
    // 发送命令模式
    i2c_data_transmit(I2C0, OLED_CMD_MODE);
    while(!i2c_flag_get(I2C0, I2C_FLAG_TBE));
    
    // 发送命令
    i2c_data_transmit(I2C0, cmd);
    while(!i2c_flag_get(I2C0, I2C_FLAG_TBE));
    
    // 发送停止信号
    i2c_stop_on_bus(I2C0);
    while(I2C_CTL0(I2C0) & I2C_CTL0_STOP);
    
    return true;
}

// I2C写数据
static bool oled_write_data(uint8_t data)
{
    // 等待I2C空闲
    while(i2c_flag_get(I2C0, I2C_FLAG_BUSY));
    
    // 发送起始信号
    i2c_start_on_bus(I2C0);
    while(!i2c_flag_get(I2C0, I2C_FLAG_SBSEND));
    
    // 发送设备地址
    i2c_master_addressing(I2C0, OLED_ADDRESS, I2C_TRANSMITTER);
    while(!i2c_flag_get(I2C0, I2C_FLAG_ADDSEND));
    i2c_flag_clear(I2C0, I2C_FLAG_ADDSEND);
    
    // 发送数据模式
    i2c_data_transmit(I2C0, OLED_DATA_MODE);
    while(!i2c_flag_get(I2C0, I2C_FLAG_TBE));
    
    // 发送数据
    i2c_data_transmit(I2C0, data);
    while(!i2c_flag_get(I2C0, I2C_FLAG_TBE));
    
    // 发送停止信号
    i2c_stop_on_bus(I2C0);
    while(I2C_CTL0(I2C0) & I2C_CTL0_STOP);
    
    return true;
}

// OLED初始化
bool oled_init(void)
{
    // 使能I2C时钟和GPIO时钟
    rcu_periph_clock_enable(RCU_I2C0);
    rcu_periph_clock_enable(RCU_GPIOB);
    
    // 配置I2C引脚 (PB8/PB9)
    gpio_af_set(GPIOB, GPIO_AF_4, GPIO_PIN_8 | GPIO_PIN_9);
    gpio_mode_set(GPIOB, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_8 | GPIO_PIN_9);
    gpio_output_options_set(GPIOB, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, GPIO_PIN_8 | GPIO_PIN_9);
    
    // 配置I2C参数
    i2c_deinit(I2C0);
    i2c_clock_config(I2C0, 400000, I2C_DTCY_2);
    i2c_mode_addr_config(I2C0, I2C_I2CMODE_ENABLE, I2C_ADDFORMAT_7BITS, 0x00);
    i2c_enable(I2C0);
    i2c_ack_config(I2C0, I2C_ACK_ENABLE);
    
    // 等待OLED上电稳定
    delay_ms(100);
    
    // 初始化OLED
    oled_write_cmd(0xAE); // 关闭显示
    oled_write_cmd(0xD5); // 设置时钟分频因子
    oled_write_cmd(0x80);
    oled_write_cmd(0xA8); // 设置多路复用率
    oled_write_cmd(0x3F);
    oled_write_cmd(0xD3); // 设置显示偏移
    oled_write_cmd(0x00);
    oled_write_cmd(0x40); // 设置显示开始行
    oled_write_cmd(0x8D); // 电荷泵设置
    oled_write_cmd(0x14);
    oled_write_cmd(0x20); // 设置内存地址模式
    oled_write_cmd(0x02); // 页地址模式
    oled_write_cmd(0xA1); // 段重定义设置
    oled_write_cmd(0xC8); // 行扫描顺序
    oled_write_cmd(0xDA); // 设置COM引脚硬件配置
    oled_write_cmd(0x12);
    oled_write_cmd(0x81); // 设置对比度
    oled_write_cmd(0xCF);
    oled_write_cmd(0xD9); // 设置预充电周期
    oled_write_cmd(0xF1);
    oled_write_cmd(0xDB); // 设置VCOMH
    oled_write_cmd(0x30);
    oled_write_cmd(0xA4); // 全局显示开启
    oled_write_cmd(0xA6); // 设置正常显示
    oled_write_cmd(0xAF); // 开启显示
    
    // 清空显示
    oled_clear();
    
    return true;
}

// 清空显示
void oled_clear(void)
{
    // 清空缓冲区
    memset(oled_buffer, 0, sizeof(oled_buffer));
    
    // 更新显示
    for(uint8_t i = 0; i < OLED_PAGE_NUM; i++) {
        oled_set_position(0, i);
        for(uint8_t j = 0; j < OLED_WIDTH; j++) {
            oled_write_data(0x00);
        }
    }
}

// 开启显示
void oled_display_on(void)
{
    oled_write_cmd(0xAF);
}

// 关闭显示
void oled_display_off(void)
{
    oled_write_cmd(0xAE);
}

// 设置显示位置
void oled_set_position(uint8_t x, uint8_t y)
{
    // 参数检查
    if(x >= OLED_WIDTH || y >= OLED_PAGE_NUM) {
        return;
    }
    
    oled_write_cmd(0xB0 + y);
    oled_write_cmd(((x & 0xF0) >> 4) | 0x10);
    oled_write_cmd(x & 0x0F);
}

// 写入一个字符
void oled_write_char(uint8_t x, uint8_t y, char ch)
{
    // 参数检查
    if(x >= OLED_WIDTH || y >= OLED_PAGE_NUM || ch < 32 || ch > 127) {
        return;
    }
    
    // 计算字符索引
    uint8_t c = ch - 32;
    
    // 设置位置
    oled_set_position(x, y);
    
    // 写入字符数据
    for(uint8_t i = 0; i < 6; i++) {
        // 更新缓冲区
        oled_buffer[y][x + i] = font6x8[c][i];
        
        // 写入数据
        oled_write_data(font6x8[c][i]);
    }
}

// 写入字符串
void oled_write_string(uint8_t x, uint8_t y, const char *str)
{
    // 参数检查
    if(x >= OLED_WIDTH || y >= OLED_PAGE_NUM || str == NULL) {
        return;
    }
    
    uint8_t pos = x;
    
    // 逐个写入字符
    while(*str != '\0') {
        // 检查是否超出显示范围
        if(pos > OLED_WIDTH - 6) {
            break;
        }
        
        // 写入字符
        oled_write_char(pos, y, *str);
        
        // 更新位置和字符指针
        pos += 6;
        str++;
    }
}

// 绘制位图
void oled_draw_bmp(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1, const uint8_t *bmp)
{
    // 参数检查
    if(x0 >= OLED_WIDTH || y0 >= OLED_PAGE_NUM || 
       x1 >= OLED_WIDTH || y1 >= OLED_PAGE_NUM || 
       x0 > x1 || y0 > y1 || bmp == NULL) {
        return;
    }
    
    uint16_t j = 0;
    
    // 逐页写入
    for(uint8_t y = y0; y <= y1; y++) {
        oled_set_position(x0, y);
        
        // 逐列写入
        for(uint8_t x = x0; x <= x1; x++) {
            // 更新缓冲区
            oled_buffer[y][x] = bmp[j];
            
            // 写入数据
            oled_write_data(bmp[j++]);
        }
    }
}

// OLED自检
bool oled_self_test(void)
{
    // 清空显示
    oled_clear();
    
    // 显示测试文本
    oled_write_string(0, 0, "OLED Test");
    oled_write_string(0, 2, "Hello World!");
    
    // 延时2秒
    delay_ms(2000);
    
    // 清空显示
    oled_clear();
    
    return true;
}

