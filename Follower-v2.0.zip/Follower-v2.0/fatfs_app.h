#ifndef __FATFS_APP_H
#define __FATFS_APP_H

#include "gd32f4xx.h"
#include <stdbool.h>
#include "rtc.h"  // 包含RTC_Time定义

// 函数声明
bool FATFS_Init(void);
bool FATFS_CheckStatus(void);
bool FATFS_ReadConfig(float *ratio, float *limit, uint8_t *hide_mode);
bool FATFS_SaveConfig(float ratio, float limit, uint8_t hide_mode);
bool FATFS_WriteLog(const char *message, RTC_Time *time);
bool FATFS_SaveSampleData(float voltage, RTC_Time *time, bool is_over_limit);

#endif





