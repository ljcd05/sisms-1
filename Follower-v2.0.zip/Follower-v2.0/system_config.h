#ifndef __SYSTEM_CONFIG_H
#define __SYSTEM_CONFIG_H

#include "gd32f4xx.h"
#include "systick.h"
#include <stdbool.h>

// 系统配置结构体
typedef struct {
    float ratio;     // 变比
    float limit;     // 电压阈值
    uint8_t hide_mode; // 隐藏模式
} SystemConfig;

// 全局变量声明
extern SystemConfig sys_config;
extern uint32_t scan_count;
extern uint32_t scan_error_count;
extern bool is_scanning;
extern uint32_t scan_interval;
extern uint32_t last_scan_time;

// 函数声明
void reset_system_config(void);
bool load_system_config(void);
bool save_system_config(void);
float apply_ratio(float voltage);
bool check_over_limit(float voltage);
void check_scan_button(void);

#endif



