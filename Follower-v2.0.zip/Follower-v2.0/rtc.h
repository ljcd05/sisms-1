#ifndef __RTC_H
#define __RTC_H

#include "gd32f4xx.h"
#include <stdbool.h>
#include <stddef.h>

// RTC时间结构体
typedef struct {
    uint16_t year;   // 年份 (2000-2099)
    uint8_t month;   // 月份 (1-12)
    uint8_t day;     // 日期 (1-31)
    uint8_t hour;    // 小时 (0-23)
    uint8_t minute;  // 分钟 (0-59)
    uint8_t second;  // 秒钟 (0-59)
} RTC_Time;

// 函数声明 - 重命名以避免与库冲突
bool rtc_init_custom(void);
bool rtc_set_time(RTC_Time *time);
bool rtc_get_time(RTC_Time *time);

// 内部辅助函数声明
static uint8_t rtc_bcd2_to_dec(uint8_t val);
static uint8_t rtc_dec_to_bcd2(uint8_t val);

#endif




