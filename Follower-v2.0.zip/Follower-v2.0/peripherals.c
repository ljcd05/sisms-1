#include "peripherals.h"
#include "gd32f4xx.h"
#include "systick.h"
#include <stdbool.h>
#include <stddef.h>

// 按键端口和引脚定义
GPIO_TypeDef* key_ports[KEY_COUNT] = {GPIOB, GPIOB, GPIOB, GPIOB, GPIOB};
uint16_t key_pins[KEY_COUNT] = {GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3, GPIO_PIN_4};

// 按键状态
bool key_pressed[KEY_COUNT] = {false, false, false, false, false};
uint32_t key_press_time[KEY_COUNT] = {0, 0, 0, 0, 0};
uint32_t key_debounce_time[KEY_COUNT] = {0, 0, 0, 0, 0};  // 添加去抖动时间数组

// GPIO初始化
void gpio_init(void)
{
    // 使能GPIO时钟
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_GPIOC);
    
    // 配置LED引脚 (PC13)
    gpio_mode_set(GPIOC, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GPIO_PIN_13);
    gpio_output_options_set(GPIOC, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_13);
    gpio_bit_set(GPIOC, GPIO_PIN_13);  // 默认关闭LED
    
    // 配置按键引脚
    for(uint8_t i = 0; i < KEY_COUNT; i++) {
        gpio_mode_set(key_ports[i], GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, key_pins[i]);
    }
}

// 键盘扫描函数
void key_scan(void)
{
    uint8_t i;
    uint32_t current_time = get_tick();
    
    // 扫描所有按键
    for(i = 0; i < KEY_COUNT; i++) {
        // 读取按键状态
        bool current_state = gpio_input_bit_get(key_ports[i], key_pins[i]) == 0;
        
        // 检测按键按下
        if(current_state && !key_pressed[i]) {
            // 去抖动处理
            if(current_time - key_debounce_time[i] > 20) {  // 20ms去抖动
                key_pressed[i] = true;
                key_press_time[i] = current_time;
            }
        }
        // 检测按键释放
        else if(!current_state && key_pressed[i]) {
            // 去抖动处理
            if(current_time - key_debounce_time[i] > 20) {  // 20ms去抖动
                key_pressed[i] = false;
                key_debounce_time[i] = current_time;
                
                // 计算按键持续时间
                uint32_t duration = current_time - key_press_time[i];
                
                // 处理按键事件
                if(duration < KEY_LONG_PRESS_TIME) {
                    // 短按
                    key_short_press_handler(i);
                } else {
                    // 长按
                    key_long_press_handler(i);
                }
            }
        }
    }
}

// 检查按键是否按下
bool key_is_pressed(uint8_t key)
{
    // 参数检查
    if(key >= KEY_COUNT) {
        return false;
    }
    
    return key_pressed[key];
}

// 短按处理函数
void key_short_press_handler(uint8_t key)
{
    // 根据按键执行不同操作
    switch(key) {
        case 0:  // 按键1
            // 切换LED状态
            gpio_bit_toggle(GPIOC, GPIO_PIN_13);
            break;
            
        case 1:  // 按键2
            // 自定义操作
            break;
            
        case 2:  // 按键3
            // 自定义操作
            break;
            
        case 3:  // 按键4
            // 自定义操作
            break;
            
        case 4:  // 按键5
            // 自定义操作
            break;
            
        default:
            break;
    }
}

// 长按处理函数
void key_long_press_handler(uint8_t key)
{
    // 根据按键执行不同操作
    switch(key) {
        case 0:  // 按键1
            // 自定义操作
            break;
            
        case 1:  // 按键2
            // 自定义操作
            break;
            
        case 2:  // 按键3
            // 自定义操作
            break;
            
        case 3:  // 按键4
            // 自定义操作
            break;
            
        case 4:  // 按键5
            // 自定义操作
            break;
            
        default:
            break;
    }
}

