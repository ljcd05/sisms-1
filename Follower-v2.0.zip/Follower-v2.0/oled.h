#ifndef __OLED_H
#define __OLED_H

#include "gd32f4xx.h"
#include <stdbool.h>

// OLED参数定义
#define OLED_WIDTH      128
#define OLED_HEIGHT     64
#define OLED_PAGE_NUM   8  // OLED_HEIGHT/8

// OLED I2C地址
#define OLED_ADDRESS    0x78  // 0x3C << 1

// OLED控制字节
#define OLED_CMD_MODE   0x00  // 命令模式
#define OLED_DATA_MODE  0x40  // 数据模式

// 函数声明
bool oled_init(void);
void oled_clear(void);
void oled_display_on(void);
void oled_display_off(void);
void oled_set_position(uint8_t x, uint8_t y);
void oled_write_char(uint8_t x, uint8_t y, char ch);
void oled_write_string(uint8_t x, uint8_t y, const char *str);
void oled_draw_bmp(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1, const uint8_t *bmp);
bool oled_self_test(void);

#endif
