#include "gd32f4xx.h"
#include "peripherals.h"
#include "systick.h"

static volatile uint32_t delay_count = 0;
static volatile uint32_t tick_count = 0;

// 获取系统滴答计数值 - 添加static关键字
static uint32_t get_systick_value(void)
{
    return SysTick->VAL;
}

// SysTick中断处理函数
void SysTick_Handler(void)
{
    if(delay_count > 0) {
        delay_count--;
    }
    tick_count++;
}

// 初始化SysTick
void systick_init(void)
{
    // 配置SysTick为1ms中断
    SysTick_Config(SystemCoreClock / 1000);
}

// 获取tick计数
uint32_t get_tick(void)
{
    return tick_count;
}

// 毫秒延时
void delay_ms(uint32_t ms)
{
    delay_count = ms;
    while(delay_count > 0);
}

