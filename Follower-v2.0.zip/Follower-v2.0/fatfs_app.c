#include "fatfs_app.h"
#include "ff.h"
#include "diskio.h"
#include <stdio.h>
#include <string.h>

// 文件系统变量
static FATFS fs;
static FIL config_file;
static FIL data_file;
static FIL log_file;

// 初始化文件系统
bool FATFS_Init(void)
{
    FRESULT res;
    
    // 挂载文件系统
    res = f_mount(&fs, "", 1);
    if(res != FR_OK) {
        // 如果挂载失败，尝试格式化
        MKFS_PARM format_opts = {
            .fmt = FM_FAT32,
            .au_size = 0,
            .align = 0,
            .n_root = 0,
            .n_fat = 0
        };
        
        res = f_mkfs("", &format_opts, NULL, 0);
        if(res != FR_OK) {
            return false;
        }
        
        // 重新挂载
        res = f_mount(&fs, "", 1);
        if(res != FR_OK) {
            return false;
        }
        
        // 创建必要的目录
        f_mkdir("/config");
        f_mkdir("/data");
        f_mkdir("/logs");
    }
    
    return true;
}

// 保存配置
bool FATFS_SaveConfig(float ratio, float limit, uint8_t hide_mode)
{
    FRESULT res;
    UINT bw;
    char config_data[50];
    
    // 打开配置文件
    res = f_open(&config_file, "/config/system.cfg", FA_CREATE_ALWAYS | FA_WRITE);
    if(res != FR_OK) {
        return false;
    }
    
    // 写入配置数据
    sprintf(config_data, "%.2f,%.2f,%d", (double)ratio, (double)limit, hide_mode);
    
    res = f_write(&config_file, config_data, strlen(config_data), &bw);
    
    // 关闭文件
    f_close(&config_file);
    
    return (res == FR_OK);
}

// 读取配置
bool FATFS_ReadConfig(float *ratio, float *limit, uint8_t *hide_mode)
{
    FRESULT res;
    UINT br;
    char config_data[50];
    double temp_ratio, temp_limit;
    int temp_hide_mode;
    
    // 打开配置文件
    res = f_open(&config_file, "/config/system.cfg", FA_READ);
    if(res != FR_OK) {
        return false;
    }
    
    // 读取配置数据
    res = f_read(&config_file, config_data, sizeof(config_data) - 1, &br);
    if(res != FR_OK || br == 0) {
        f_close(&config_file);
        return false;
    }
    
    // 确保字符串结束
    config_data[br] = '\0';
    
    // 解析配置数据
    if(sscanf(config_data, "%lf,%lf,%d", &temp_ratio, &temp_limit, &temp_hide_mode) != 3) {
        f_close(&config_file);
        return false;
    }
    
    // 设置返回值
    *ratio = (float)temp_ratio;
    *limit = (float)temp_limit;
    *hide_mode = (uint8_t)temp_hide_mode;
    
    // 关闭文件
    f_close(&config_file);
    
    return true;
}

// 保存采样数据
bool FATFS_SaveSampleData(float voltage, RTC_Time *time, bool is_over_limit)
{
    FRESULT res;
    UINT bw;
    
    // 创建文件名（按日期）
    char filename[32];
    sprintf(filename, "/data/%04d%02d%02d.csv", 
            time->year, time->month, time->day);
    
    // 检查文件是否存在
    FILINFO fno;
    bool file_exists = (f_stat(filename, &fno) == FR_OK);
    
    // 打开数据文件（追加模式）
    res = f_open(&data_file, filename, FA_OPEN_ALWAYS | FA_WRITE);
    if(res != FR_OK) {
        return false;
    }
    
    // 如果是新文件，写入CSV头
    if(!file_exists) {
        const char *header = "Time,Voltage,OverLimit\r\n";
        f_write(&data_file, header, strlen(header), &bw);
    }
    
    // 移动到文件末尾
    f_lseek(&data_file, f_size(&data_file));
    
    // 写入数据
    char data_line[50];
    sprintf(data_line, "%02d:%02d:%02d,%.2f,%d\r\n", 
            time->hour, time->minute, time->second, 
            (double)voltage, is_over_limit ? 1 : 0);
    
    res = f_write(&data_file, data_line, strlen(data_line), &bw);
    
    // 关闭文件
    f_close(&data_file);
    
    return (res == FR_OK);
}

// 写入日志
bool FATFS_WriteLog(const char *message, RTC_Time *time)
{
    FRESULT res;
    UINT bw;
    
    // 创建文件名（按月份）
    char filename[32];
    sprintf(filename, "/logs/%04d%02d.log", 
            time->year, time->month);
    
    // 打开日志文件（追加模式）
    res = f_open(&log_file, filename, FA_OPEN_ALWAYS | FA_WRITE);
    if(res != FR_OK) {
        return false;
    }
    
    // 移动到文件末尾
    f_lseek(&log_file, f_size(&log_file));
    
    // 写入日志
    char log_line[100];
    sprintf(log_line, "[%04d-%02d-%02d %02d:%02d:%02d] %s\r\n", 
            time->year, time->month, time->day, 
            time->hour, time->minute, time->second, 
            message);
    
    res = f_write(&log_file, log_line, strlen(log_line), &bw);
    
    // 关闭文件
    f_close(&log_file);
    
    return (res == FR_OK);
}

// 实现FatFS需要的时间获取函数
DWORD get_fattime(void)
{
    RTC_Time time;
    
    // 获取当前RTC时间
    rtc_parameter_struct rtc_time;
    rtc_current_time_get(&rtc_time);
    
    // 转换为RTC_Time结构体格式
    time.year = rtc_time.year + 2000; // 假设RTC年份是从2000年开始的两位数
    time.month = rtc_time.month;
    time.day = rtc_time.date;
    time.hour = rtc_time.hour;
    time.minute = rtc_time.minute;
    time.second = rtc_time.second;
    
    // 转换为FatFS需要的格式
    return ((time.year - 1980) << 25) |
           (time.month << 21) |
           (time.day << 16) |
           (time.hour << 11) |
           (time.minute << 5) |
           (time.second / 2);
}









