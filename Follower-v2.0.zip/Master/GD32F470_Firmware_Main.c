/**
 * GD32F470 主程序
 * 实现与上位机通信的所有功能
 */

#include "gd32f4xx.h"
#include "systick.h"
#include "uart.h"
#include "rtc.h"
#include "flash.h"
#include "adc.h"
#include "oled.h"
#include "led.h"
#include "gpio.h"
#include "tf_card.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* 定义系统状态 */
typedef enum {
    SYSTEM_DISCONNECTED,  // 系统未连接
    SYSTEM_IDLE,          // 系统空闲
    SYSTEM_SAMPLING       // 系统采样中
} system_state_t;

/* 定义系统配置 */
typedef struct {
    float ratio;          // 变比
    float limit;          // 阈值
    uint32_t sample_period; // 采样周期(ms)
    bool hide_mode;       // 隐藏模式
} system_config_t;

/* 全局变量 */
static system_state_t system_state = SYSTEM_DISCONNECTED;
static system_config_t system_config = {
    .ratio = 1.0f,
    .limit = 100.0f,
    .sample_period = 1000,
    .hide_mode = false
};
static bool is_sampling = false;
static uint32_t last_sample_time = 0;

/* 命令处理函数声明 */
static void handle_test_command(void);
static void handle_rtc_config_command(const char* datetime);
static void handle_now_command(void);
static void handle_conf_command(void);
static void handle_ratio_command(const char* param);
static void handle_limit_command(const char* param);
static void handle_config_save_command(void);
static void handle_config_read_command(void);
static void handle_start_command(void);
static void handle_stop_command(void);
static void handle_hide_command(void);
static void handle_unhide_command(void);
static void handle_led_command(const char* param);
static void handle_oled_command(const char* param);
static void handle_adc_command(const char* param);
static void handle_gpio_command(const char* param);

/* 命令表结构 */
typedef struct {
    const char* cmd;
    void (*handler)(const char* param);
} command_entry_t;

/* 命令表 */
static const command_entry_t command_table[] = {
    {"test", handle_test_command},
    {"RTCConfig", handle_rtc_config_command},
    {"Now", handle_now_command},
    {"conf", handle_conf_command},
    {"ratio", handle_ratio_command},
    {"limit", handle_limit_command},
    {"config save", handle_config_save_command},
    {"config read", handle_config_read_command},
    {"start", handle_start_command},
    {"stop", handle_stop_command},
    {"hide", handle_hide_command},
    {"unhide", handle_unhide_command},
    {"led", handle_led_command},
    {"oled", handle_oled_command},
    {"adc", handle_adc_command},
    {"gpio", handle_gpio_command},
    {NULL, NULL}  // 表结束标记
};

/* 函数原型 */
static void system_init(void);
static void process_command(const char* command);
static void perform_sampling(void);
static void update_oled_display(void);
static void update_led_status(void);

/**
 * 主函数
 */
int main(void)
{
    char command_buffer[256] = {0};
    uint16_t buffer_index = 0;
    
    /* 系统初始化 */
    system_init();
    
    /* 设置OLED显示为disconnected */
    oled_clear();
    oled_display_string(0, 0, "disconnected");
    
    /* 主循环 */
    while(1) {
        /* 处理串口接收 */
        if(uart_available()) {
            char c = uart_getchar();
            
            /* 处理回车换行 */
            if(c == '\r' || c == '\n') {
                if(buffer_index > 0) {
                    command_buffer[buffer_index] = '\0';
                    process_command(command_buffer);
                    buffer_index = 0;
                }
            } 
            /* 处理退格 */
            else if(c == '\b' && buffer_index > 0) {
                buffer_index--;
            }
            /* 存储字符 */
            else if(buffer_index < sizeof(command_buffer) - 1) {
                command_buffer[buffer_index++] = c;
            }
        }
        
        /* 执行周期采样 */
        if(is_sampling) {
            uint32_t current_time = get_tick();
            if(current_time - last_sample_time >= system_config.sample_period) {
                perform_sampling();
                last_sample_time = current_time;
            }
        }
        
        /* 更新OLED显示 */
        update_oled_display();
        
        /* 更新LED状态 */
        update_led_status();
    }
}

/**
 * 系统初始化
 */
static void system_init(void)
{
    /* 配置系统时钟 */
    SystemInit();
    
    /* 初始化SysTick */
    systick_config();
    
    /* 初始化UART */
    uart_init(115200);
    
    /* 初始化RTC */
    rtc_init();
    
    /* 初始化Flash */
    flash_init();
    
    /* 初始化ADC */
    adc_init();
    
    /* 初始化OLED */
    oled_init();
    
    /* 初始化LED */
    led_init();
    
    /* 初始化GPIO */
    gpio_init();
    
    /* 初始化TF卡 */
    tf_card_init();
    
    /* 从Flash读取配置 */
    if(read_config_from_flash(&system_config.ratio, &system_config.limit)) {
        /* 配置读取成功 */
    }
}

/**
 * 处理接收到的命令
 */
static void process_command(const char* command)
{
    /* 连接命令特殊处理 */
    if(strncmp(command, "connect", 7) == 0) {
        system_state = SYSTEM_IDLE;
        oled_clear();
        oled_display_string(0, 0, "system idle");
        uart_send_string("Connected\r\n");
        return;
    }
    
    /* 断开命令特殊处理 */
    if(strncmp(command, "disconnect", 10) == 0) {
        system_state = SYSTEM_DISCONNECTED;
        is_sampling = false;
        oled_clear();
        oled_display_string(0, 0, "disconnected");
        uart_send_string("Disconnected\r\n");
        return;
    }
    
    /* 查找并执行命令 */
    for(int i = 0; command_table[i].cmd != NULL; i++) {
        if(strncmp(command, command_table[i].cmd, strlen(command_table[i].cmd)) == 0) {
            const char* param = command + strlen(command_table[i].cmd);
            /* 跳过空格 */
            while(*param == ' ') param++;
            
            /* 执行命令处理函数 */
            command_table[i].handler(param);
            return;
        }
    }
    
    /* 未知命令 */
    uart_send_string("ERROR: Unknown command\r\n");
}

/**
 * 执行采样
 */
static void perform_sampling(void)
{
    /* 获取ADC采样值 */
    float voltage = adc_read_voltage();
    
    /* 应用变比 */
    voltage *= system_config.ratio;
    
    /* 获取当前时间 */
    rtc_time_t rtc_time;
    rtc_get_time(&rtc_time);
    
    /* 格式化时间和电压 */
    char time_str[32];
    sprintf(time_str, "%04d-%02d-%02d %02d:%02d:%02d", 
            rtc_time.year, rtc_time.month, rtc_time.day,
            rtc_time.hour, rtc_time.minute, rtc_time.second);
    
    /* 检查是否超过阈值 */
    bool is_over_limit = (voltage > system_config.limit);
    
    /* 控制LED2 */
    if(is_over_limit) {
        led_on(LED2);
    } else {
        led_off(LED2);
    }
    
    /* 发送采样数据 */
    char response[64];
    if(system_config.hide_mode) {
        /* 隐藏格式 - 转换为UNIX时间戳和HEX格式 */
        uint32_t unix_time = rtc_to_unix_time(&rtc_time);
        sprintf(response, "%u,%08X\r\n", unix_time, *((uint32_t*)&voltage));
    } else {
        /* 标准格式 */
        sprintf(response, "%s,%0.2fV\r\n", time_str, voltage);
    }
    
    uart_send_string(response);
}

/**
 * 更新OLED显示
 */
static void update_oled_display(void)
{
    static system_state_t last_state = SYSTEM_DISCONNECTED;
    
    /* 只在状态变化时更新OLED */
    if(system_state != last_state) {
        oled_clear();
        
        switch(system_state) {
            case SYSTEM_DISCONNECTED:
                oled_display_string(0, 0, "disconnected");
                break;
                
            case SYSTEM_IDLE:
                oled_display_string(0, 0, "system idle");
                break;
                
            case SYSTEM_SAMPLING:
                /* 采样状态下，OLED显示会在采样函数中更新 */
                break;
        }
        
        last_state = system_state;
    }
    
    /* 在采样状态下，更新时间和电压显示 */
    if(system_state == SYSTEM_SAMPLING) {
        rtc_time_t rtc_time;
        rtc_get_time(&rtc_time);
        
        char time_str[32];
        sprintf(time_str, "%02d:%02d:%02d", 
                rtc_time.hour, rtc_time.minute, rtc_time.second);
        
        float voltage = adc_read_voltage() * system_config.ratio;
        char voltage_str[16];
        sprintf(voltage_str, "%.2fV", voltage);
        
        oled_display_string(0, 0, time_str);
        oled_display_string(0, 1, voltage_str);
    }
}

/**
 * 更新LED状态
 */
static void update_led_status(void)
{
    static uint32_t led_toggle_time = 0;
    
    /* LED1闪烁指示采样状态 */
    if(is_sampling) {
        uint32_t current_time = get_tick();
        if(current_time - led_toggle_time >= 500) {  // 1秒周期，500ms切换一次
            led_toggle(LED1);
            led_toggle_time = current_time;
        }
    } else {
        led_off(LED1);
    }
}

/* 命令处理函数实现 */

static void handle_test_command(void)
{
    /* 执行自检 */
    char response[256];
    char flash_status[16] = "OK";
    char tf_status[16] = "OK";
    char tf_size[16] = "2GB";
    uint32_t flash_id = flash_read_id();
    
    /* 获取RTC时间 */
    rtc_time_t rtc_time;
    rtc_get_time(&rtc_time);
    char rtc_time_str[32];
    sprintf(rtc_time_str, "%04d-%02d-%02d %02d:%02d:%02d", 
            rtc_time.year, rtc_time.month, rtc_time.day,
            rtc_time.hour, rtc_time.minute, rtc_time.second);
    
    /* 组织响应 */
    sprintf(response, "System Test\r\nFlash: %s, TF Card: %s\r\nTF Size: %s\r\nFlash ID: 0x%08X\r\nRTC Time: %s\r\n",
            flash_status, tf_status, tf_size, flash_id, rtc_time_str);
    
    /* 发送响应 */
    uart_send_string(response);
}

static void handle_rtc_config_command(const char* datetime)
{
    int year, month, day, hour, minute, second;
    
    /* 解析日期时间 */
    if(sscanf(datetime, "%d-%d-%d %d:%d:%d", 
              &year, &month, &day, &hour, &minute, &second) ==